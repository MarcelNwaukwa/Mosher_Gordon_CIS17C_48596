/* 
 * File:   main.cpp
 * Author: Gordon Mosher
 *
 * Created on September 11, 2014, 1:16 PM
 * Driver for SimpleVector.h
 */

#include <cstdlib>
#include <iostream>
#include "SimpleVector.h"

using namespace std;


/*
 * 
 */
int main(int argc, char** argv) {
    int SIZE = 10;        // Number of elements *** no longer const!
    int count;                  // loop counter
    
    cout << "Test Driver for SimpleVector class.\n\n";
    // Create a SimpleVector of ints.
    SimpleVector<int> intTable(SIZE);

    // Create a SimpleVector of doubles.
    SimpleVector<double> doubleTable(SIZE);
    
    // Store values in the two SimpleVectors.
    for (count = 0; count < SIZE; count++) {
        intTable[count] = count * 2;
        doubleTable[count] = count * 2.14;
    }
    
    intTable.push(99);
    doubleTable.push(99.99);
    SIZE++;     // increment to match new arraySize
    cout << "The arrays are initialized with 10 elements.\n";
    cout << "The value pushed onto the int array is " << 99 << "\n";
    cout << "The value pushed onto the double array is " << 99.99 << "\n";
    cout << endl;
    
    // Display the values in the SimpleVectors.
    cout << "These values are in intTable:\n";
    //cout << intTable;         // tried to overload << but it didn't work
    for (count = 0; count < SIZE; count++) {
        cout << intTable[count] << " ";
    }
    cout << endl;
    cout << "These values are in doubleTable:\n";
    for (count = 0; count < SIZE; count++) {
        cout << doubleTable[count] << " ";
    }
    cout << endl;
    cout << endl;
        
    int v1 = intTable.pull();
    double v2 = doubleTable.pull();
    SIZE--;
    cout << "The value pulled off the int array is " << v1 << "\n";
    cout << "The value pulled off the double array is " << v2 << "\n";
    cout << endl;
    
    
   // Use the standard + operator on the elements.
   cout << "\nAdding 5 to each element of intTable"
        << " and doubleTable.\n";
   for (count = 0; count < SIZE; count++)
   {
      intTable[count] = intTable[count] + 5;
      doubleTable[count] = doubleTable[count] + 5.0;
   }
   
   // Display the values in the SimpleVectors.
   cout << "These values are in intTable:\n";
   for (count = 0; count < SIZE; count++)
      cout << intTable[count] << " ";
   cout << endl;
   cout << "These values are in doubleTable:\n";
   for (count = 0; count < SIZE; count++)
      cout << doubleTable[count] << " ";
   cout << endl;
   cout << endl;

   SIZE++; 
   cout << "INTENTIONALLY SETTING SIZE FOR NEXT LOOP BIGGER THAN ARRAY\n";
   cout << "TO TEST/DEMONSTRATE SUBSCRIPT [" << SIZE << "] IS OUT OF RANGE.\n";
   
   // Use the standard ++ operator on the elements.
   cout << "\nIncrementing each element of intTable and"
       << " doubleTable.\n";
   for (count = 0; count < SIZE; count++)
   {
      intTable[count]++;
      doubleTable[count]++;
   }
   
   // Display the values in the SimpleVectors.
   cout << "These values are in intTable:\n";
   for (count = 0; count < SIZE; count++)
      cout << intTable[count] << " ";
   cout << endl;
   cout << "These values are in doubleTable:\n";
   for (count = 0; count < SIZE; count++)
      cout << doubleTable[count] << " ";
   cout << endl;

    

    return 0;
}

