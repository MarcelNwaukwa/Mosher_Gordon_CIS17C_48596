/*
* File:   main.cpp
* Author: Dr. Mark E. Lehr
* Created on August 27, 2014, 8:05 PM
* Purpose:  First Data Structure Triangular Array
* Modified by: Gordon Mosher
* 2014-0901 bring functions into a class and make it a template
*			retain unused code, but comment it
*			submit as a single file solution - ok (no .h file)
*/

//System Libraries
#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;

//Global Constants

//Functions Prototypes
/*
int*  fillArray(int);					// for colAry
int** fillArray(int, int);
int** fillArray(int, int*);				// for triAry
void printArray(int*, int, int);		// for colAry
void printArray(int**, int, int);
void printArray(int**, int, int *);		// for triAry
void destroy(int *);
void destroy(int **, int);				// for triAry and squareAry
*/

//Class Declaration
template <class NUM>
class TriangleMatrix {
private:
	int		rows, maxCols;
	int*	colAry;							// colAry holds a random column count for each row
	NUM**	triAry;
private:
	// private Member functions
	int*  fillArray(int, int);				// for colAry
	NUM** fillArray(int, int*);				// for triAry
	void printArray(int*, int, int);		// for colAry
	void printArray(NUM**, int, int *);		// for triAry
	void destroy(int *);					// for colAry
	void destroy(NUM**, int);				// for triAry and squareAry
public:
	// default Constructor
	// Constructor declaration and inline definition
	TriangleMatrix(int r = 5, int c = 10)	// constructor has default args, so it's the default too
		{ rows = r; maxCols = c; triAry = fillArray(rows, colAry = fillArray(rows, maxCols)); }

	// Destructor declaration and inline definition
	~TriangleMatrix()
		{ destroy(colAry); destroy(triAry, rows); }

	// Members
	void printMatrix()
		{ printArray(colAry, rows, 10); printArray(triAry, rows, colAry); }

};
template <class NUM>
void TriangleMatrix<NUM>::destroy(int *array){
	//Destroy row pointers
	delete[]array;
}

template <class NUM>
void TriangleMatrix<NUM>::destroy(NUM**array, int rows){
	//Destroy cols
	for (int row = 0; row<rows; row++){
		delete[]array[row];
	}
	//Destroy row pointers
	delete[]array;
}

template <class NUM>
void TriangleMatrix<NUM>::printArray(int*array, int rows, int perLine){				// for colAry
	//Print the Array
	cout << endl;
	for (int col = 0; col<rows; col++){
		cout << array[col] << " ";
		if (col%perLine == (perLine - 1))cout << endl;
	}
	cout << endl;
}

template <class NUM>
void TriangleMatrix<NUM>::printArray(NUM**array, int rows, int *colAry){				// for triAry
	//Print the Array
	cout << endl;
	for (int row = 0; row<rows; row++){
		for (int col = 0; col<colAry[row]; col++){
			cout << array[row][col] << " ";
		}
		cout << endl;
	}
	cout << endl;
}
/*
void printArray(int**array, int rows, int cols){								// for square array
	//Print the Array
	cout << endl;
	for (int row = 0; row<rows; row++){
		for (int col = 0; col<cols; col++){
			cout << array[row][col] << " ";
		}
		cout << endl;
	}
	cout << endl;
}
*/
template <class NUM>
int* TriangleMatrix<NUM>::fillArray(int rows, int MaxCols){					// for colAry
	//Declare the 1-D Array
	int * array = new int[rows];					// on heap - 5 column counters (row lengths) 0..4
													// colAry[0..4]
	//Fill the array with random 2 digit numbers
	for (int row = 0; row<rows; row++){
		array[row] = rand() % (maxCols-1) + 2;			// random number 2 to maxCols
	}
	return array;									// return the address of the dynamic array
}

template <class NUM>
NUM** TriangleMatrix<NUM>::fillArray(int rows, int *colAry){				// for triAry
	//Declare the 2-D Array
	NUM** array = new NUM*[rows];					// heap - 5 rows of int * 
	for (int row = 0; row<rows; row++){
		//cout<<"Number of Cols = "<<colAry[row]<<endl;
		array[row] = new NUM[colAry[row]];			// heap - of colAry[row] columns, variable length
	}
	//Fill the array with random 2 digit numbers
	for (int row = 0; row<rows; row++){
		for (int col = 0; col<colAry[row]; col++){
			array[row][col] = static_cast<NUM>(rand() % 90 + 10 + 0.1);
			//cout<<"Row Col"<<row<<" "<<col<<endl;
		}
	}
	return array;
}
/*
int** fillArray(int rows, int cols){				// for square array, rows x cols
	//Declare the 2-D Array
	int ** array = new int*[rows];					// heap - 5 rows
	for (int row = 0; row<rows; row++){
		array[row] = new int[cols];					// heap - of 10 columns
													// array[0..4,0..9]
	}
	//Fill the array with random 2 digit numbers
	for (int row = 0; row<rows; row++){
		for (int col = 0; col<cols; col++){
			array[row][col] = rand() % 90 + 10;		// random number 10 to 99
		}
	}
	return array;
}
*/
//Execution Begins Here
int main(int argc, char** argv) {
	//Initialize the random number generator
	srand(static_cast<unsigned int>(time(0)));
/*
	//Declare the 2-D Array
	int rows = 5, cols = 10;
	int cls = rows, perLine = 10;
	int **array = fillArray(rows, cols);
	int *colAry = fillArray(cls);
	int **triAry = fillArray(rows, colAry);

	//Print the array
	printArray(array, rows, cols);
	printArray(colAry, cls, perLine);
	printArray(triAry, rows, colAry);

	//Delete the array
	destroy(array, rows);
	destroy(triAry, rows);
	destroy(colAry);
*/
	//Implement the class
//	TriangleMatrix* tm1 = new TriangleMatrix(10, 20);		// works! for optional argument entry
	TriangleMatrix<int>* tm1 = new TriangleMatrix<int>();	// default arguments are rows=5, maxCols=10
	tm1->printMatrix();
	delete(tm1);
	tm1 = 0;

	TriangleMatrix<float>* tm2 = new TriangleMatrix<float>();//default arguments are rows=5, maxCols=10
	tm2->printMatrix();
	delete(tm2);
	tm2 = 0;

	//Exit stage right
	system("PAUSE");
	return 0;
}
