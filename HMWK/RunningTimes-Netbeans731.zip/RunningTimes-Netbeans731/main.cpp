/* 
 * File:   main.cpp
 * Author: Gordon Mosher
 * CIS-17C w/ Mark Lehr
 *
 * Created on September 11, 2014, 9:33 PM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <cfloat> // for FLT_EPSILON

using namespace std;
// Function prototypes
double f_lg_n(double, double);
double f_sqrt_n(double, double);
double f_n(double, double);
double f_n_lg_n(double, double);
double f_n_pow2(double, double);
double f_n_pow3(double, double);
double f_two_pown(double, double);
double f_n_factorial(double, double);
// Function definitions
double f_lg_n(double ms, double ms2) {
    double r = pow(2, ms);    // all results say 1.#INF
//    double r = pow(pow(10, 0.3), ms);
    cout << "Result: " << "2^" << ms << " \tor 10^" << 0.3 * ms << "\n";
    return r;   // all results say 1.#INF
}
double f_sqrt_n(double ms, double ms2) {
    double r = pow(ms, 2);
    cout << "Result: " << r << "\n";
    return r;
}
double f_n(double ms, double ms2) {
    double r = ms;
    cout << "Result: " << r << "\n";
    cout.flush();
    return r;
}
double f_n_lg_n(double ms, double ms2) {
    double incr = pow(10.0, 13);        //10000;
    double n = incr;
    double good_n = -1.0;
    double good_r = -1.0;          // result
    double test = 0.0;
    do {
        test = n*(log(n)/log(2));
        if (test <= ms) {
            good_r = test;       // lastTest
            good_n = n;
            n+=incr;            // try again with same incr
        }
        else {
            n -= incr;          // too much, take off incr
            incr /= 10;         // take off a power of 10
            n += incr;          // try again with smaller incr
        }
    } while (incr >= (n/100000)); // if incr is less than precision, we're done
    cout << "Result: " << good_n << " \tin " << good_r << " microseconds\n";
    cout.flush();
    return good_n;
}
double f_n_pow2(double ms, double ms2) {
    double r = floor(pow(ms, 0.5));
    cout << "Result: " << r << " \tin " << ms << " microseconds" << "\n";
    return r;
}
double f_n_pow3(double ms, double ms2) {
    double cuberoot = 1.0/3.0;
    double r = floor(pow(ms+FLT_EPSILON, cuberoot));
    cout << "Result: " << r << "\n";
    return r;
}
double f_two_n(double ms, double ms2) {
    double r = floor(log10(ms)/0.301);       // 0.301 = log10(2)
    cout << "Result: " << r << "\n";  // result is log2(ms)
    return r;
}
double f_n_fact(double ms, double ms2) {
    double r = 0;
    int n=1;
    double fact = 1;
    while (ms > fact) {
        r = fact;       // lastFact (not used)
        fact *= (n+++1);  // just kidding, but it works!
//        n++;            // counter
    } 
    n--;        // step back to lastFact
    cout << "Result: " << n << "\n";
    return n;
}
/*
 * 
 */
int main(int argc, char** argv) {
    enum times_t {second, minute, hour, day, month, year, century}; // not used
    
    string stepName[7];    
    double stepMS[7];         // microseconds for each step
    stepName[0] = "second";     stepMS[0] = pow(10.0, 6.0);
    stepName[1] = "minute";     stepMS[1] = stepMS[0] * 60;
    stepName[2] = "hour";       stepMS[2] = stepMS[1] * 60;
    stepName[3] = "day ";       stepMS[3] = stepMS[2] * 24;
    stepName[4] = "month";      stepMS[4] = stepMS[3] * 30;
    stepName[5] = "year";       stepMS[5] = stepMS[3] * 365.24; //365.2424
    stepName[6] = "century";    stepMS[6] = stepMS[5] * 100;

    enum funcs_t {lg_n, sqrt_n, n, n_lg_n, n_pow2, n_pow3, two_n, n_factorial};
    string funcName[8]; // not used
//    void* fOf[8];
//    fOf[lg_n] = (void *)&f_lg_n;    kinda works
    double (*fOf[8])(double, double);   // declare array of function pointers
        fOf[lg_n] = &f_lg_n;            // and initialize
        fOf[sqrt_n] = &f_sqrt_n;
        fOf[n] = &f_n;
        fOf[n_lg_n] = &f_n_lg_n;
        fOf[n_pow2] = &f_n_pow2;
        fOf[n_pow3] = &f_n_pow3;
        fOf[two_n] = &f_two_n;
        fOf[n_factorial] = &f_n_fact;

    cout << "Problem 1-1\n" << endl;
    cout << "Comparison of running times\n\n";
    
    cout << "For each function f(n) and time t in the following table, \n";
    cout << "determine the largest size n of a problem that can be solved \n";
    cout << "in time t, assuming that the algorithm to solve the problem \n";
    cout << "takes f(n) microseconds.\n\n";
    
    //    for (time_t t = second; t < century; t+=1) {
    cout << endl;
    cout << "lg_n\tsolved non-numerically.\n";
    for (int t = 0; t < 7; t++) {
        cout << "lg_n\tper " << stepName[t] << "\t";
            double result = (*fOf[lg_n])(stepMS[t], stepMS[t]);
    }
    cout << endl;
    for (int t = 0; t < 7; t++) {
        cout << "sqrt_n\tper " << stepName[t] << "\t";
            double result = (*fOf[sqrt_n])(stepMS[t], stepMS[t]);
    }
    cout << endl;
    for (int t = 0; t < 7; t++) {
        cout << "n    \tper " << stepName[t] << "\t";
            double result = (*fOf[n])(stepMS[t], stepMS[t]);
    }
    cout << endl;
    cout << "n_lg_n\tsolved by interpolation.\n";
    for (int t = 0; t < 7; t++) {
        cout << "n_lg_n\tper " << stepName[t] << "\t";
            double result = (*fOf[n_lg_n])(stepMS[t], stepMS[t]);
    }
    cout << endl;
    for (int t = 0; t < 7; t++) {
        cout << "n_pow2\tper " << stepName[t] << "\t";
            double result = (*fOf[n_pow2])(stepMS[t], stepMS[t]);
    }
    cout << endl;
    for (int t = 0; t < 7; t++) {
        cout << "n_pow3\tper " << stepName[t] << "\t";
            double result = (*fOf[n_pow3])(stepMS[t], stepMS[t]);
    }
    cout << endl;
    for (int t = 0; t < 7; t++) {
        cout << "two_n\tper " << stepName[t] << "\t";
            double result = (*fOf[two_n])(stepMS[t], stepMS[t]);
    }
    cout << endl;
    for (int t = 0; t < 7; t++) {
        cout << "n!  \tper " << stepName[t] << "\t";
            double result = (*fOf[n_factorial])(stepMS[t], stepMS[t]);
    }
    return 0;
}
