/*
 * Gordon Mosher
 * Sort Order Comparisons
 * Project: Modified LehrSortComparisons
 * v.2014-1115
 *
*/
#include <cstdlib>      // rand())
#include <iostream>
#include <string>       // to_string())
#include <cmath>
#include <ctime>        // for time(0)
#include <map>
using namespace std;
 
void quickSort(int [], int, int);
int pivot(int [], int, int);
void swap(int&, int&);
void print(int [], const int&);
void merge(int*,int,const int, const int);
void merge_sort(int*, const int, const int);
void heapsort(int [], int);
void buildheap(int [], int);
void heapify(int [], int, int);

//globals
map<string, int> stats; // for analysis data
int debugN;          // debug global for N
const int arraySize = 1e5;   // 1e5 runs in 4 seconds, 1e6 in 55 seconds
int test[arraySize];         // global to save stack space
int unsorted[arraySize];     // global to save stack space
 
int main(){
    //Initialize the random number generator
    srand(static_cast<unsigned int>(time(0)));

    //int test[] = { 7, -13, 1, 3, 10, 5, 2, 4 };
/*
    const int arraySize = 1e5;   // 1e5 runs in 4 seconds, 1e6 in 55 seconds
    int test[arraySize];
    int unsorted[arraySize];
*/
    for (int i=0; i<arraySize; i++) {
        unsorted[i]=rand() % arraySize;
    }
    for (int i=0; i<arraySize; i++) {test[i]=unsorted[i];} // unsort test[]
    int N = sizeof(test)/sizeof(int);
    debugN = N;      // for global debug
    cout << "Size of test array :"  << N << endl;
    //cout << "Size of test array :"  << n << endl;
    cout << "Array size N = " << arraySize << ", N*(log(N)/log(2)) = " << N*(log(N)/log(2)) << endl;
 
    cout << "Before sorting : " << endl;
    print(test, N);
 
    clock_t clock_start;
    clock_start= clock();
    quickSort(test, 0, N-1);
    stats["QuickSort-clock ticks(ms)"] = clock() - clock_start;
    for (int i=0; i<arraySize; i++) {test[i]=unsorted[i];} // unsort test[]
    clock_start= clock();
    merge_sort(test, 0, N-1);
    stats["MergeSort-clock ticks(ms)"] = clock() - clock_start;
    for (int i=0; i<arraySize; i++) {test[i]=unsorted[i];} // unsort test[]
    clock_start= clock();
    heapsort(test, N);
    stats["Heapsort-clock ticks(ms)"] = clock() - clock_start;
    map<string, int>::iterator pos = stats.begin();
    for( pos=stats.begin(); pos != stats.end(); ++pos ) {
        cout << "Stats[" << pos->first << "] = " << stats[pos->first] << " times. \n";
        if (pos->first.find("clock ticks")!=-1) cout << endl;
        // pos->first is the key, happens to be a string in map<string, int> stats;
        // stats[pos->first] is the value, same as pos->second
    }
    cout << endl;

 
    cout << endl << endl << "After sorting : " << endl;
    print(test, N);
     
    return 0;
}
 
/**
 * Quicksort.
 * @param a - The array to be sorted.
 * @param first - The start of the sequence to be sorted.
 * @param last - The end of the sequence to be sorted.
*/
void quickSort( int a[], int first, int last ) {
    int pivotElement;
 
    if(first < last)
    {
        if (debugN<=100) cout << "qs" << last - first << " ";
        stats["QuickSort iterations"]++;
        pivotElement = pivot(a, first, last);
        quickSort(a, first, pivotElement-1);
        quickSort(a, pivotElement+1, last);
    }
}
 
/**
 * Find and return the index of pivot element.
 * @param a - The array.
 * @param first - The start of the sequence.
 * @param last - The end of the sequence.
 * @return - the pivot element
*/
int pivot(int a[], int first, int last) {
    int  p = first;
    int pivotElement = a[first];
 
    if (debugN<=100) cout << "pv(n)" << last-first << " ";
    for(int i = first+1 ; i <= last ; i++)
    {
        /* If you want to sort the list in the other order, change "<=" to ">" */
        if(a[i] <= pivotElement)
        {
            p++;
            swap(a[i], a[p]);
            if (debugN<=100) cout << "sw." << i << "-" << p << " ";
            stats["QuickSort swaps"]++;
        }
    }
 
    if (debugN<=100) cout << "SW." << p << "-" << first << " " << endl;
    stats["QuickSort swaps"]++;
    swap(a[p], a[first]);
 
    return p;
}
 
 
/**
 * Swap the parameters.
 * @param a - The first parameter.
 * @param b - The second parameter.
*/
void swap(int& a, int& b){
    int temp = a;
    a = b;
    b = temp;
}
 
/**
 * Print an array.
 * @param a - The array.
 * @param N - The size of the array.
*/
void print(int a[], const int& N){
    for(int i = 0 ; i < N ; i++)
        if (debugN<=100) cout << "array[" << i << "] = " << a[i] << endl;
} 

void merge(int* A,int p,const int q, const int r){
    stats["Merge iterations"]++;
    const int n_1=q-p+1;
    const int n_2=r-q;
    int* L = new int [n_1+1];
    int* R = new int [n_2+1];
    L[n_1]=0;
    R[n_2]=0;
    for(int i = 0; i < n_1; i++) 
        L[i] = A[p+i];
    for (int j = 0; j < n_2; j++)
        R[j] = A[q+j+1];
    stats["MergeSort assignLR"]+=n_1;
    stats["MergeSort assignLR"]+=n_2;

    int i=0;
    int j=0;
    // for(int k = p; k <= r; p++)   broken code
    int k;
    for(k=p; k <= r && i < n_1 && j < n_2; ++k)
    {
        stats["MergeSort assignA"]++;
        if(L[i] <= R[j])
        {
            A[k] = L[i];
            i++;
        }
        else
        {
            A[k] = R[j];
            j++;        
        }
    }
    // Added the following two loop.
    // Note only zero or one loop will actually activate.
    while (i < n_1) {A[k++] = L[i++];stats["MergeSort assignA"]++;}
    while (j < n_2) {A[k++] = R[j++];stats["MergeSort assignA"]++;}
}     

void merge_sort(int* A, const int p, const int r){
    if (p < r) 
    {
        stats["MergeSort iterations"]++;
        int q = (p+r)/2;
        merge_sort(A, p,q);
        merge_sort(A,q+1,r);
        merge(A,p,q,r);
    }
}

void heapsort(int A[], int length)//	       (takes O(n lg n) time)
{
    char buffer[33];
	int heapsize = length;
	//string m = std::to_string(length);
        string mm = string(itoa(length, buffer, 10));
        stats["Heapsort len=" + string(itoa(length, buffer, 10)) + " iterations"]++;
	buildheap(A, length);	//Take the unsorted list and make it a heap
	for (int i = length-1; i >=1; i--)
	{
		swap(A[0], A[i]);
		heapsize--;
		heapify(A, heapsize, 0);		
	}
}

void buildheap(int A[], int length)	//     (takes O(n) time)
{	
    stats["Buildheap O(n) iterations"]++;
	for (int i = floor((length)/2); i >= 0 ; i--)
		heapify(A, length, i);
}

void heapify(int A[], int heapsize, int root) //(takes O(h) h is the height of root
{
    char buffer[33];
//        stats["Heapify O(h) len=" + string(itoa(heapsize, buffer, 10)) + " iterations"]++;
        stats["Heapify O(h = lg n) iterations"]++;
	int left = 2*root+1, 
		right = 2*root +2,
		largest;
	
	if ( (left < heapsize) && (A[left] > A[root]))
		largest = left;
	else 
		largest = root;
	
	if ( (right < heapsize) && (A[right] > A[largest]))
		largest = right;
		
	if (largest != root)
	{
		swap(A[root], A[largest]);
		heapify(A, heapsize, largest);
	}
}
