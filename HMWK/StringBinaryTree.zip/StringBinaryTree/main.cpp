/* 
 * File:   main.cpp
 * Author: Dave - Gordon Mosher
 * CIS-17C
 * Instructor: Dr. Mark Lehr
 *
 * Created on November 23, 2014, 5:57 PM
 */
// search for "bool debug" to set debug flags
// also you can comment the srand() to get same data every run
// note: random_shuffle has no seed already, use C++11 shuffle if want to seed

#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include <ctime>        // for time(0)
#include <cmath>        // log()
#include <vector>
#include <algorithm>    // random_shuffle
//#include <random>

using namespace std;
// globals

// =============================================================================
// Source for StringBinaryTree.h
#ifndef STRINGBINARYTREE_H
#define STRINGBINARYTREE_H
class StringBinaryTree {
public:
    static int nodeCount;
private:
    struct Node {
        string value;
        Node *left;
        Node *right;
    };
    Node *root;
    int maxDepth;       // updated by checkDepth...()
    
    // Private member functions
    void insert(Node *&, Node *&);
    void destroySubTree(Node *);
    void deleteNode(string, Node *&);
    void makeDeletion(Node *&);
    void balance(Node *&);      // only works for root
    int checkDepthInOrder(Node *, char, int);
    void displayInOrder(Node *, char, int) const;
    void displayPreOrder(Node *) const;
    void displayPostOrder(Node *) const;
    
public:
    StringBinaryTree() {root = NULL;}           // Constructor
    ~StringBinaryTree() {destroySubTree(root);} // Destructor
    
    // Binary tree operations
    void insertNode(string);
    bool searchNode(string);
    void remove(string);
    void balance()
        { balance(root); };
    int checkDepthInOrder()               // no params overload is public
        { maxDepth = 0; return checkDepthInOrder(root, '=', 0)-1; }
    void displayInOrder() const
        { displayInOrder(root, '=', 0); }  // 0 is depth of branch, 0 for =root
    void displayPreOrder() const
        { displayPreOrder(root); }
    void displayPostOrder() const
        { displayPostOrder(root); }
};
int StringBinaryTree::nodeCount = 0;
#endif
// =============================================================================
// Source for StringBinaryTree.cpp
void StringBinaryTree::insertNode(string str) {
    Node *newNode;      // automatic pointer to new node
    
    newNode = new Node;         // create the node on the heap
    newNode->value = str;
    newNode->left = NULL;       // because new nodes are all leaves
    newNode->right = NULL;
    insert(root, newNode);      // insert the node into the tree at root
        // root is a reference parameter, so it's modifiable
        // and will be set to newNode if the tree is empty
        // otherwise newNode will recursively look down the
        //      left or right branches till it finds a NULL
    nodeCount++;
}

void StringBinaryTree::insert(Node *&nodePtr, Node *&newNode) {
    if (nodePtr == NULL) {
        nodePtr = newNode;
    }
    else if (newNode->value < nodePtr->value) {
        insert(nodePtr->left, newNode);         // look left
    }
    else {
        insert(nodePtr->right, newNode);        // look right
    }
}
void StringBinaryTree::destroySubTree(Node *nodePtr) {  // called by Destructor
    if (nodePtr)                                         // it's recursive
    {
       if (nodePtr->left)
          destroySubTree(nodePtr->left);         // go left first
       if (nodePtr->right)
          destroySubTree(nodePtr->right);        // then go right
       delete nodePtr;                           // finally whack the node
       nodeCount--;
    }
}
bool StringBinaryTree::searchNode(string str) {
    Node *nodePtr = root;

    while (nodePtr)
    {
       if (nodePtr->value == str)
          return true;
       else if (str < nodePtr->value)
          nodePtr = nodePtr->left;
       else
          nodePtr = nodePtr->right;
    }
    return false;
}
void StringBinaryTree::remove(string str) {
    deleteNode(str, root);
}
void StringBinaryTree::deleteNode(string str, Node *&nodePtr)
{
    bool debug = false;
    if (debug) cout << "." << endl;
    if (nodePtr == NULL) {
        cout << "Cannot delete empty node.\n";
    }
    else if (str < nodePtr->value) {
        if (debug) cout << "L(" << nodePtr->value << ")\n";
        deleteNode(str, nodePtr->left);
    }
    else if (str > nodePtr->value) {
        if (debug) cout << "R\n";
        deleteNode(str, nodePtr->right);
    }
    else {
        if (debug) cout << "*makeDEL*\n";
        makeDeletion(nodePtr);
    }
}
//***********************************************************
// makeDeletion takes a reference to a pointer to the node  *
// that is to be deleted. The node is removed and the       *
// branches of the tree below the node are re-attached.     *
// code learned in GaddiS Chapter 20 page 1160              *
//***********************************************************
void StringBinaryTree::makeDeletion(Node *&nodePtr) {
    Node *tempNodePtr;                       // for attaching left tree

    if (nodePtr == NULL)
       cout << "Cannot delete empty node.\n";
    else if (nodePtr->right == NULL) {
       tempNodePtr = nodePtr;
       nodePtr = nodePtr->left;                  // Re-attach the left child
       delete tempNodePtr;
       nodeCount--;
    }
    else if (nodePtr->left == NULL) {
       tempNodePtr = nodePtr;
       nodePtr = nodePtr->right;  // Re-attach the right child
       delete tempNodePtr;
       nodeCount--;
    }
    // If the node has two children.
    else {
       // Move one node the right.
       tempNodePtr = nodePtr->right;
       // Go to the end left node.
       while (tempNodePtr->left)
          tempNodePtr = tempNodePtr->left;
       // Re-attach the left subtree.
       tempNodePtr->left = nodePtr->left;

       tempNodePtr = nodePtr;
       // Re-attach the right subtree.
       nodePtr = nodePtr->right;
       delete tempNodePtr;
       nodeCount--;
    }
}
void StringBinaryTree::balance(Node *&nodePtr) {      // only works for root
    vector<string> vStr;
    if (nodeCount < 10)
        return;                         // not enough elements to balance
    bool debug = false;
    int holdNodeCount = nodeCount;
    cout << "\nBalancing tree.\n";
//    for (int i = 0; i < nodeCount; i++) {
    while (nodeCount > 0) {                  // flatten the tree to a vector
        vStr.push_back(nodePtr->value);
        remove(nodePtr->value);
    }
    cout << "\nSort to cherry pick strong trunk.\n";
    sort(vStr.begin(), vStr.end());   // sort the list
    for (vector<string>::iterator it=vStr.begin(); it!=vStr.end(); ++it)
        if (debug) cout << *it << endl;    
    // hand pick 7 items to build a strong trunk
    cout << "Cherry pick 7 elements to build a strong trunk.\n";
    int loc;
    loc = floor(vStr.size() * .50);          // midpoint
    insertNode(vStr[loc]);
    cout << vStr[loc] + "(.50) ";
    vStr.erase(vStr.begin()+loc);
    loc = floor(vStr.size() * .25);          // midpoint
    insertNode(vStr[loc]);
    cout << vStr[loc] + "(.25) ";
    vStr.erase(vStr.begin()+loc);
    loc = floor(vStr.size() * .75);          // midpoint
    insertNode(vStr[loc]);
    cout << vStr[loc] + "(.75) ";
    vStr.erase(vStr.begin()+loc);
    loc = floor(vStr.size() * .125);          // midpoint
    insertNode(vStr[loc]);
    cout << vStr[loc] + "(.125) ";
    vStr.erase(vStr.begin()+loc);
    loc = floor(vStr.size() * .875);          // midpoint
    insertNode(vStr[loc]);
    cout << vStr[loc] + "(.875) ";
    vStr.erase(vStr.begin()+loc);
    loc = floor(vStr.size() * .375);          // midpoint
    insertNode(vStr[loc]);
    cout << vStr[loc] + "(.375) ";
    vStr.erase(vStr.begin()+loc);
    loc = floor(vStr.size() * .625);          // midpoint
    insertNode(vStr[loc]);
    cout << vStr[loc] + "(.625) ";
    vStr.erase(vStr.begin()+loc);
    cout << "\nShuffle remaining data to more evenly build branches and leaves.\n";
//    shuffle(vStr.begin(), vStr.end(), default_random_engine(time(0)));   // randomize the list
    random_shuffle(vStr.begin(), vStr.end());   // randomize the list
    while (nodeCount < holdNodeCount/*+7*/) {
        if (debug) cout << vStr.back() << endl;
        insertNode(vStr.back());
        vStr.pop_back();
    }
}
int StringBinaryTree::checkDepthInOrder(Node *nodePtr, char dirChar, int depth) {
    bool debug = true;
//    static int depth = 1;
    if (depth > maxDepth)
        maxDepth = depth;
    static string sTab = "\t\t\t\t\t\t\t\t\t\t";
    if (nodePtr) {
        if (debug) cout << dirChar << "(" << nodePtr->value << ")\n";
//        depth++;
        /*if (nodePtr->left)*/ checkDepthInOrder(nodePtr->right, 'R', depth+1);
        cout << "------->" << sTab.substr(0, depth) << '"' << nodePtr->value
                << "\" (depth=" << depth << ")" << endl;
        /*if (nodePtr->right)*/ checkDepthInOrder(nodePtr->left, 'L', depth+1);
    }
    else {
        if (debug) cout << dirChar << "(NULL)\n";
//        depth--;
    }
    return maxDepth;    // not necessary to return it, it's global to the class
}
void StringBinaryTree::displayInOrder(Node *nodePtr, char dirChar, int depth) const {
    bool debug = false;
//    static int depth = 1;
    static string sTab = "\t\t\t\t\t\t\t\t\t\t";
    if (nodePtr) {
        if (debug) cout << dirChar << "(" << nodePtr->value << ")\n";
//        depth++;
        /*if (nodePtr->left)*/ displayInOrder(nodePtr->left, 'L', depth+1);
        cout << "------->" << sTab.substr(0, depth) << '"' << nodePtr->value
                << "\" (depth=" << depth << ")" << endl;
        /*if (nodePtr->right)*/ displayInOrder(nodePtr->right, 'R', depth+1);
    }
    else {
        if (debug) cout << dirChar << "(NULL)\n";
//        depth--;
    }
}
void StringBinaryTree::displayPreOrder(Node *nodePtr) const {
    if (nodePtr) {
        cout << nodePtr->value << endl;
        displayPreOrder(nodePtr->left);
        displayPreOrder(nodePtr->right);
    }
}
void StringBinaryTree::displayPostOrder(Node *nodePtr) const {
    if (nodePtr) {
        displayPostOrder(nodePtr->left);
        displayPostOrder(nodePtr->right);
        cout << nodePtr->value << endl;
    }
}

// =============================================================================
/*
 * 
 */
int main(int argc, char** argv) {
    //Initialize the random number generator
    srand(static_cast<unsigned int>(time(0)));  // comment to get same data
    
    string s0="0000000000";
    string s = "Hello World -- Good Bye";
    StringBinaryTree *myTree = new StringBinaryTree();
    
    cout << "Inserting nodes.\n";
    for (int i = 0; i < 1e2; i++) {
        //int num = rand() % 1000;
        ostringstream convert;
        //convert << num;
        convert << rand() % (int)1e4;   //RAND_MAX 32,767
        int strLen = convert.str().length();
        string nodeValue = s0.substr(0,4-strLen) + convert.str();
        myTree->insertNode(nodeValue);
        cout << nodeValue << endl;
    }

    myTree->insertNode(s);
    myTree->insertNode("Hello");
    myTree->insertNode("World");
    myTree->insertNode("**");
    myTree->insertNode("Good");
    myTree->insertNode("Bye");
    myTree->insertNode("**");

    cout << "\nPreOrder traversal:\n";
    myTree->displayPreOrder();
    cout << "\nPostOrder traversal:\n";
    myTree->displayPostOrder();
    cout << "\nInOrder traversal:\n";
    myTree->displayInOrder();
    
    cout << "\nLooking for " << s << " ";
    if (myTree->searchNode(s))
        cout << " Found it!\n";
    myTree->remove(s);
    cout << "\nLooking for " << s << " ";
    if (myTree->searchNode(s))
        cout << " Found it!\n";
    else
        cout << " Not Found :(\n";
    
    myTree->remove("**");
    myTree->remove("**");
    myTree->remove("**");     // stack overflows if search for this again FIXED
    cout << "\n/////////////////////////////////////////////////////////////\n";
    cout << "\nCheck depth by InOrder traversal:\n";
    cout << "Note: This list is In REVERSE Order traversal\n";
    cout << "      so tree prints right(bigger) to left(smaller).\n";
    cout << "\nmaxDepth is " << myTree->checkDepthInOrder()
            << ", optimum is ceil(log(nodeCount)/log(2))="
            << ceil(log(myTree->nodeCount)/log(2))
            << ", anything under "
            << 2* ceil(log(myTree->nodeCount)/log(2)) << " is good!" << endl;

    cout << "\nnodeCount = " << myTree->nodeCount << endl;

    myTree->balance();          // balance it!
    cout << "\n/////////////////////////////////////////////////////////////\n";
    cout << "\nCheck depth by InOrder traversal:\n";
    cout << "Note: This list is In REVERSE Order traversal\n";
    cout << "      so tree prints right(bigger) to left(smaller).\n";
    cout << "\nmaxDepth is " << myTree->checkDepthInOrder()
            << ", optimum is ceil(log(nodeCount)/log(2))="
            << ceil(log(myTree->nodeCount)/log(2))
            << ", anything under "
            << 2* ceil(log(myTree->nodeCount)/log(2)) << " is good!" << endl;

    cout << "\nnodeCount = " << myTree->nodeCount << endl;


    cout << "\nDone.\n";
    return 0;
}

