/* 
 * File:   main.cpp
 * Author: Gordon Mosher
 * Professor: Dr. Mark Lehr
 * Class: CIS-17C
 * Project: Final
 * BattleshipBooty
 * derived from BattleshipSTL (11-9-14)
 * and MyBinarySearchTreeTemplate (11-27-14)
 * and HashOrderTest (10-29-14)
 * and LinkedListTemplateEnhansed (10-14-14)
 *
 * Created on Decemeber 6, 2014
 * 
 * Programmer note: be careful!
 *                      data structures are rc row, column
 *                      but data entry is cr column, row
 *
 */

//#include <stdio.h>      // sprintf())
#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include <ctime>

#include <vector>
#include <stack>
#include <queue>
#include <iterator>
#include <map>
#include <set>
#include <algorithm>
#include <numeric>
#include <list>
#include "BinarySearchTree.h"
#include "LnkdLst.h"


using namespace std;

//*** HASHTABLE
class hashLink {
public:
    int key;
    int data;
    hashLink *next;
};
class hashSlot {
public:
    hashLink *head;
};

// globals
// shipInitMaster is by the rules in Wikipedia - Battleship_(puzzle))
#define shipInitMaster  {4,3,3,2,2,2,1,1,1,1}
#define shipInit        {4,3,3,2,2,2,1,1,1,1}
string shipInitStr =   "{4,3,3,2,2,2,1,1,1,1}";
const int shipInitCount = 10;
bool seeShips = true;
bool seeHints = true;
unsigned int gameWinnings = 0;   // 2^32 = 4,294,967,296
hashSlot *hs;                           // global for reward()
BinarySearchTree<int> *myTree;          // global for reward()
map<int,int> prizes;                    // global for reward()
LnkdLst<int> llist(0);                   // global for reward()
const char water = '~';
const char miss = '.';//(char)183;//'@';
const char hit = '$';//(char)149;//'H';//(char)164;//'X';//'H' 137 135

//*** HASHTABLE FUNCTIONS
//#define hashExpr (((s[0] - 'a') * 26*26*26) + ((s[1] - 'a') * 26*26) + ((s[2] - 'a') * 26) + (s[3] - 'a'))
#define hashExpr key / 10
int hashItem(int key) {
//**/    cout << "hash:" << s[0] << s[1] << (((s[0]-'a') * 26) + (s[1] - 'a'))<<endl;
//    return (((s[0]-'a') * 26) + (s[1] - 'a'));
    return key / 10;           // key range is 1e4, slots = 1e3
}
void insertItem(hashSlot *hs, int key, int data) {
    int location = hashItem(key);
    hashLink *clink = new hashLink;
    clink->key = key;
    clink->data = data;
    clink->next = hs[location].head;
    hs[location].head = clink;    
    if (data >= 990) {
        cout << "L" << location << " K" << key << " D" << data << " ";
    }
//**/    if (location == 0) cout << "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD";
}
void fillHashTable(hashSlot *hs, string *sa, int N) {
    for (int i = 0; i < N; i++) {
//        cout << "hashfillloop" << i;
//        insertItem(hs, sa[i]);
    }
}
hashLink *hashSearch(hashSlot *hs, int searchKey, int iter){
    int position = -1;
    bool found = false;
    
    int location = hashItem(searchKey);
    hashLink *worker = hs[location].head;
    while (worker != 0 && worker->key != searchKey) {
        worker = worker->next;
    }
    if (worker != 0) {
        found = true;
    }
    if (iter == 0) if (found) cout << "X"; else cout << "O";
    return worker;
}
int time_10_hashSearches(hashSlot *hs, string *sa, int N, 
                                string *searchData, int max_SD) {
    clock_t seek_start = clock();
    cout << "Hash   Seek results = ";
    for (int j = 0; j < 1000; j++)
    for (int i = 0; i < max_SD; i++) {
        //hashSearch(hs, sa, N, searchData[i], j);
    }
    clock_t totalTime = clock() - seek_start;
    cout << endl;       // for X's and O's
    return totalTime;
}
void purgeHashTable(hashSlot *hs) {
    hashLink *worker;
    int msgCount = 0;
    
    for (int i = 0; i < 26 * 26 * 26 * 26; i++) { // 676*676 slots
        if (hs[i].head && msgCount < 5) {     // only show first 5 nonzero heads
            msgCount++;
            cout << "Purge:" << i << " " << hs[i].head << " ";
            if (hs[i].head) cout << hs[i].head->next << endl; else cout << endl;
            // this could be a workerhead and show all next while head
        }
        if (hs[i].head) {    // head
            do {
//                cout << ".";  // << endl;     // be careful c/b 1e7 dots
                worker = hs[i].head;
                hs[i].head = hs[i].head->next;
                delete worker;
            } while (hs[i].head);
        }
//        cout << endl;    // for dots above
    }
}



//*** BATTLESHIP FUNCTIONS
/*
 *         insertItem(hs, key, data);      // fill the hash table
        llist.prepend(key);             // stick the keys in a LnkdLst too
        myTree->insertNode(key);        // stick the keys in the tree too
        prizes[key] = data;             // stick the keys in red/black map
 */
int reward() {
    hashLink *worker;
    bool found = false;
    int winnings = 0;
    int key = 0;
    int times = 11;
    do {
        key = rand() % (int)1e4;       // grab a random prize
        found = myTree->searchNode(key);
        //worker = hashSearch(hs, key, 1);        // the last param controls debug
        times--;
    } while (!found && times > 1);
    if (found) {
        worker = hashSearch(hs, key, 1);        // the last param controls debug
        if (worker->data != prizes[key]) {
            cout << "MISMATCH IN PRIZE DATABASE" << endl;
        }
        winnings = worker->data;
        cout << " Booty=$" << winnings 
                << " times " << times 
                << " = $" << winnings * times << endl;
    }
    else {
        cout << " NO BOOTY!" << endl;
    }
    return winnings * times;
}
void stats(map<int, char> &ocean, map<int, int> &shipGrid) {
    static int prevHits = 0;
    int ships = 0;
    int hits = 0;
    int misses = 0;
    for (int row = 9; row >= 0; row--) {
        for (int col = 0; col <= 9; col++) {
            if (shipGrid[row*10+col] != 0) {
                ships++;
            }
            if (ocean[row*10+col] == hit) {
                hits++;
            }
            if (ocean[row*10+col] == miss) {
                misses++;
            }
        }
    }
    int newHits = hits - prevHits;
    for (int i = 0; i < newHits; i++) {
        gameWinnings += reward();
    }
    prevHits = hits;
    cout << "Total Targets: " << ships << ", Hits: " 
            << hits << ", Misses: " << misses 
            << ", Booty: $" << gameWinnings << endl;
}
bool unsunk(map<int, char> &ocean, map<int, int> &shipGrid) {
    bool unsunk = false;
    for (int row = 9; row >= 0; row--) {
        for (int col = 0; col <= 9; col++) {
            if (shipGrid[row*10+col] != 0) {
                if (ocean[row*10+col] != hit) {
                    unsunk = true;
                }
            }
        }
    }
    return unsunk;
}
bool fire(map<int, char> &ocean, map<int, int> &shipGrid, int row, int col) {
    bool bHit = false;
    if (shipGrid[row*10+col] > 0) {     // hit
        ocean[row*10+col] = hit;
        bHit = true;
    }
    else {
        ocean[row*10+col] = miss;
    }
    return bHit;
}
void bomb(map<int, char> &ocean, map<int, int> &shipGrid) {
    for (int row = 9; row >= 0; row--) {
        for (int col = 0; col <= 9; col++) {
            fire(ocean, shipGrid, row, col);
        }
    }
}
void photon_torpedo(map<int, char> &ocean, map<int, int> &shipGrid, char rc, int index1) {
    for (int index2 = 0; index2 <= 9; index2++) {
        if (rc == 'R') {
            fire(ocean, shipGrid, index1, index2);
        }
        else { // rc == 'C'
            fire(ocean, shipGrid, index2, index1);
        }
    }
}
void conventional_torpedo(map<int, char> &ocean, map<int, int> &shipGrid, char rc, int index1) {
    bool bHit = false;
    for (int index2 = 0; !bHit && index2 <= 9; index2++) {
        if (rc == 'r') {
            bHit = fire(ocean, shipGrid, index1, index2);
        }
        else { // rc == 'c'
            bHit = fire(ocean, shipGrid, index2, index1);
        }
    }
}
void drawOcean(map<int, char> &ocean, map<int, int> &shipGrid,
                                int rowHint[], int colHint[]) {
        if (seeHints) {
            cout << "    ";
            for (int col = 0; col <= 9; col++) {
                cout << ' ' << colHint[col] << ' ';
            }
            cout << endl;
        }

//        for ( int x = 0; x < 256; x++ ) {cout<< x <<". "<< (char)x <<" "<<endl;}
        for (int row = 9; row >= 0; row--) {
            cout << ' ' << row << "  ";
            for (int col = 0; col <= 9; col++) {
                if (seeShips && shipGrid[row*10+col] > 0
                             && ocean[row*10+col] != hit
                             && ocean[row*10+col] != miss) {
                    ocean[row*10+col] = '0' + shipGrid[row*10+col] % 10;
                                        //shipSectionNum
                }
                if (!seeShips && ocean[row*10+col] != hit && ocean[row*10+col] != miss) {
                    ocean[row*10+col] = water;
                }
                cout << ' ' << ocean[row*10+col] << ' ';
            }
            if (seeHints) {
                cout << ' ' << rowHint[row];
            }
            cout << endl;
        }
        cout << "    ______________________________" << endl;
        cout << "    ";
        for (int col = 0; col <= 9; col++) {
            cout << ' ' << col << ' ';
        }
        cout << endl;
}
void placeShip(map<int, char> &ocean, map<int, int> &shipGrid, int shipSize) {
    bool validPosition;
    int h, v;
    int row, col;
    do {
        validPosition = true;      // assume good, until proven otherwise
//        cout << ".";
        // random vertical or horizontal
        v = rand() % 2; // 0 or 1, false or true
        h = !v;         // opposite of v
//        cout << "vh = " << v << h << "  ";
        // random LEGAL position
/*
        if (h) {
            int r_max = 9;
            int c_max = 9 - h*shipSize;
        }
        if (v) {
            int r_max = 9 - v*shipSize;
            int c_max = 9;
        }
*/
        row = rand() % (10 - v*shipSize);
        col = rand() % (10 - h*shipSize);
        cout << "vh(" << v << h << ") "<< "rc(" << row << col << ")  ";
        // make sure no collisions with other ships
        for (int i = 0; i < shipSize; i++) {
            if (shipGrid[((row+(v*i))*10)+(col+(h*i))] > 0) {  // collision
                cout << "\n      collision, retry ";
                validPosition = false;
                break;  // break the for loop
            }
        }
    } while (!validPosition);
    // place it in shipGrid
    for (int i = 0; i < shipSize; i++) {
        shipGrid        [((row+(v*i))*10)+(col+(h*i))] = shipSize*10+i+1;

        if (seeShips) {
                ocean   [((row+(v*i))*10)+(col+(h*i))] = '0'+i+1;//shipSectionNum
        }
//        ocean[88] = '8';
//        ocean[99] = '9';
        cout << "(" << ((row+(v*i))*10)+(col+(h*i)) << ")";
    }
    cout << endl;
}
/*
 * 
 */
int main(int argc, char** argv) {
    string inputString;
    int userInput, userRow, userCol;
    bool gameOver = false;
    int rowHint[10], colHint[10];
    //Initialize the random number generator
    srand(static_cast<unsigned int>(time(0)));
    
    // make the ocean
    map<int, char> ocean;
    map<int, int> shipGrid;
    for (int row = 9; row >= 0; row--) {
        for (int col = 0; col <= 9; col++) {
            ocean[row*10+col] = water;
            shipGrid[row*10+col] = 0;
        }
    }
    // make the ships
//cout << (int)'8' << (char)65 << endl;
//printf("%c\n", 65);
    int shipArray[]= shipInit;//{4,3,3,2,2,2,1,1,1,1};//{2,1};//
    multiset<int> shipSet;
    multiset<int>::iterator it;
    shipSet.insert (shipArray,shipArray+shipInitCount);// load shipSet from shipArray
    cout << "shipSet contains:";
    for (it=shipSet.begin(); it!=shipSet.end(); ++it)
        cout << ' ' << *it;
    cout << endl;    
    // put the ships in the ocean - biggest first, use reverse_iterator
    multiset<int>::reverse_iterator rit;
    for (rit=shipSet.rbegin(); rit!=shipSet.rend(); ++rit) {
        cout << "Placing ship of size " << *rit << ' ';// << endl;
        placeShip(ocean, shipGrid, *rit);
//        cout << endl;
    }
    // calculate the Hints
    for (int row = 9; row >= 0; row--) {rowHint[row] = 0;}
    for (int col = 0; col <= 9; col++) {colHint[col] = 0;}
    stack<int> *s[10];   // stack the columns
    for (int col = 0; col < 10; col++) {
        s[col] = new stack<int>;
        for (int row = 9; row >= 0; row--) {
            s[col]->push(shipGrid[row*10+col]);
        }
        // no iterators for queue, so move data to a vector
        vector<int> v1;          // pop the stack into a vector for count()
        for (int row = 9; row >= 0; row--) {
            v1.push_back(s[col]->top());
            s[col]->pop();
        }
        colHint[col] = 10 - count(v1.begin() , v1.end() , 0);
        v1.clear();     // don't clear if <pointer>
    }
    queue<int> *q[10];   // queue the rows
    for (int row = 0; row < 10; row++) {
        q[row] = new queue<int>;
        for (int col = 0; col <= 9; col++) {
            q[row]->push(shipGrid[row*10+col]);
        }
        // no iterators for queue, so move data to a vector
        vector<int> v2;
        for (int col = 0; col <= 9; col++) {
            v2.push_back(q[row]->front());
            q[row]->pop();
        }
        rowHint[row] = 10 - count(v2.begin() , v2.end() , 0);
        v2.clear();     // don't clear if <pointer>
    }
    // setup prize structures
    //BinarySearchTree<string> *
    myTree = new BinarySearchTree<int>();
    //hashSlot *
    hs = new hashSlot[1000];     // 676 slots for hash table
                                            // default constructor inits 0
    for (int i = 0; i < 1000; i++) {
        hs[i].head = NULL;  // i needed this ?? why doesn't new init ??
    }
    clock_t hash_fill_start = clock();
    cout << "Filling hash table with booty (only showing first 10)..." << endl;
    for (int i = 0; i < 1000; i++) {
        //fillHashTable(hs, 1000);
        int key = rand() % (int)1e4;   //RAND_MAX 32,767
                                // mod 1e4 gives 1e3 elements a 1 in 10 chance
        int data = i;
        //cout << key << " ";
        insertItem(hs, key, data);      // fill the hash table
        llist.prepend(key);             // stick the keys in a LnkdLst too
        myTree->insertNode(key);        // stick the keys in the tree too
        prizes[key] = data;             // stick the keys in red/black map
        
    }
    //pd[iter].hash_fill_time = clock() - hash_fill_start;


    // start the game loop
    bool oneTime = true;
    do {
        if (oneTime) {
//            oneTime = false;
            cout << endl;
            cout << "---------------------------------------------------------\n";
            cout << "Battleship Booty v1.0 (c)2014 G. D. Mosher\n";
            cout << "---------------------------------------------------------\n";
            cout << "If running in Netbeans IDE, set project Console Type\n";
            cout << "                   to Standard Output for getline(cin.\n";
            cout << "---------------------------------------------------------\n";
            cout << "Numbers on top and right are hints for hits/row or column.\n";
            cout << "Numbers on left and bottom are row and column numbers.\n";
//            cout << "In the rules, ships don't touch each other, but these can.\n";
            cout << hit << " is a hit, " << miss << " is a miss.\n";
            cout << "---------------------------------------------------------\n";
            cout << "Type -3<Enter><Enter> to toggle seeHints.\n";
            cout << "Type -2<Enter><Enter> to toggle seeShips.\n";
            cout << "Type -1<Enter><Enter> to give up.\n";
            cout << "---------------------------------------------------------\n";
            cout << "## (col, row) launches SSM surface to surface missile.\n";
            cout << "c# or r# launches conventional torpedo.\n";
            cout << "C# or R# launches photon torpedo.\n";
            cout << "CR or RC or b drops an A-bomb.  You win!!!\n";
            cout << "---------------------------------------------------------\n";
            cout << "Beware this is an NP-complete problem, which in computational\n";
            cout << "complexity theory means it is both NP (nondeterministic \n";
            cout << "in polynomial time) and NP-hard. That means it can't be solved\n";
            cout << "fast and you can't even be sure you did it optimally when\n";
            cout << "it finally is done!(Wikipedia NP-complete)\n";
            cout << "Type <Enter><Enter> to start!\n";
            getline(cin, inputString);
        }
        // draw the ocean
        drawOcean(ocean, shipGrid, rowHint, colHint);

        // wait for user action
        do {
            if (oneTime) {
                oneTime = false;
                cout << "INSTRUCTIONS ARE SHOWN BEFORE FIRST GRID DRAW.\n";
                cout << "To play, type cr, where cr is a column and row number.\n";
            }
            stats(ocean, shipGrid);
            cout << "There are " << shipInitCount 
                    << " ships of these sizes " << shipInitStr << ".\n";
            cout << "Type cr<Enter><Enter> to fire: ";
            getline(cin, inputString);
            stringstream(inputString) >> userInput;
        } while (userInput < -3 || userInput > 99);
        if (inputString.length() > 0 && inputString[0] == 'b') {
            bomb(ocean, shipGrid);
        } else if (userInput == 0 && inputString.length() >= 2 && inputString != "00") {
            if (    (toupper(inputString[0]) == 'R' && toupper(inputString[1]) == 'C')
                 || (toupper(inputString[0]) == 'C' && toupper(inputString[1]) == 'R')) {
                bomb(ocean, shipGrid);
            } else if (toupper(inputString[0]) == 'R' || toupper(inputString[0]) == 'C') {
                if (inputString[1] >= '0' && inputString[1] <= '9') {
                    if (toupper(inputString[0]) == inputString[0]) { // uppercase
                        photon_torpedo(ocean, shipGrid,
                                        inputString[0], inputString[1] - '0');
                    }
                    else {
                        conventional_torpedo(ocean, shipGrid,
                                        inputString[0], inputString[1] - '0');
                    }
                }
            }    
        } else if (userInput == -1) {
            gameOver = true;
        } else if (userInput == -2) {
            seeShips = !seeShips;
            cout << "Toggle seeShips" << endl;
        } else if (userInput == -3) {
            seeHints = !seeHints;
            cout << "Toggle seeHints" << endl;
        } else {
            userRow = userInput % 10;
            userCol = userInput / 10;
            cout << "Fire: " << userCol << userRow << endl;

            // process user action
            fire(ocean, shipGrid, userRow, userCol);
        }
        
        // loop until game over
        if (!unsunk(ocean, shipGrid)) {
            drawOcean(ocean, shipGrid, rowHint, colHint);
            stats(ocean, shipGrid);
            cout << "You win!!!";
            gameOver = true;
        }
//        gameOver = true;      // DEBUG
    } while (!gameOver);
    
/*
 *     clock_t hash_delete_start = clock();
    purgeHashTable(hs);     // delete hashLink's
    delete[] hs;    // hash table
    //pd[iter].hash_delete_time = clock() - hash_delete_start;
*/
    return 0;
}

