/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on October 22, 2014, 8:11 PM
 * Modified November 2, 2014
 * Gordon Mosher
 * Added sum(), savings, and quickSort - 3 more recursive functions
 */

#include <cstdlib>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <cmath>
using namespace std;

int bcoeff(int,int);
int gcd(int,int);
void towers(int,char,char,char);
int max(int *,int);
float sinR(float);
float cosR(float);
int sum(int *,int);
double savings(double, double, int);
// prototypes for quickSort
void swap(int &value1, int &value2);
int partition(int set[], int start, int end);
void quickSort(int set[], int start, int end);


int main(int argc, char** argv) {
    //Utilize the recursive binary coefficient function
    int rows=17;
    for(int n=0;n<rows;n++){
        for(int k=0;k<=n;k++){
            cout<<bcoeff(n,k)<<" ";
        }
        cout<<endl;
    }
    //Testing the gcd with euclid algorithm
    int n=26*6,m=26*17;
    cout<<endl;
    cout<<"The GCD of "<<n<<" and "<<m<<" = "<<gcd(m,n)<<endl;
    cout<<"The GCD of "<<m<<" and "<<n<<" = "<<gcd(n,m)<<endl;
    cout<<endl;
    //Play the game towers of hanoi
    int nDsks=3;
    char peg1='A',peg2='B',peg3='C';
    towers(nDsks,peg1,peg2,peg3);
    cout << endl;
    //Fill array and find the max
    srand(static_cast<unsigned int>(time(0)));
    int size=100;
    int array[size];
    cout << "Array[100] contents: ";
    for(int i=0;i<size;i++){
        cout << (array[i]=rand()%90+10) << " ";
    }
    cout << endl;
    quickSort(array, 0, size-1);
    cout << "Array[100] quickSorted: ";
    for(int i=0;i<size;i++){
        cout << array[i] << " ";
    }
    cout<<endl;
    cout<<"Sum of 0 elements in the array = "<<sum(array,0)<<endl;
    cout<<"Sum of 1 elements in the array = "<<sum(array,1)<<endl;
    cout<<"Sum of 2 elements in the array = "<<sum(array,2)<<endl;
    cout<<"Sum of 3 elements in the array = "<<sum(array,3)<<endl;
    cout<<"Sum of 4 elements in the array = "<<sum(array,4)<<endl;
    cout<<"Sum of all elements in the array = "<<sum(array,size)<<endl;
    cout<<endl;
    cout<<"Max element in the array = "<<max(array,size)<<endl;
    cout<<endl;
    
    //Testing the savings function
    int years = 2;
    double intRate = .10;
    double pv = 1000.00;
    cout << "In " << years << " years at "
            << intRate*100 << "%, $" << pv << " savings grows to $" 
            << savings(pv, intRate, years) << endl << endl;
    
    //Testing out recursive trig functions
    float angDeg=.01;
    float angRad=angDeg*atan(1)/45;
    cout<<"Angle = "<<angDeg<<" sin = "<<sin(angRad)<<
            " our sin = "<<sinR(angRad)<<endl;
    cout<<"Angle = "<<angDeg<<" cos = "<<cos(angRad)<<
            " our cos = "<<cosR(angRad)<<endl;
    //Exit stage right
    return 0;
}

void swap(int &value1, int &value2) {
    int temp = value1;
    value1 = value2;
    value2 = temp;
}
int partition(int set[], int start, int end) {
    int pivotValue;
    int pivotIndex, mid;
    
    mid = (start + end) / 2;
    swap(set[start], set[mid]);
    pivotIndex = start;
    pivotValue = set[start];
    for (int scan = start + 1; scan <= end; scan++) {
        if (set[scan] < pivotValue) {
            pivotIndex++;
            swap(set[pivotIndex], set[scan]);
        }
    }
    swap(set[start], set[pivotIndex]);
    return pivotIndex;
}
void quickSort(int set[], int start, int end) {
    int pivotPoint;
    
    if (start < end) {
        // Get the pivot point.
        pivotPoint = partition(set, start, end);
        // Sort the first sublist
        quickSort(set, start, pivotPoint - 1);
        // Sort the second sublist.
        quickSort(set, pivotPoint + 1, end);
    }
}

double savings(double pv, double intRate, int years) {
    if (years==0) return pv;
    pv*=(1+intRate);         // add one year of interest
    return savings(pv, intRate, years-1); // and the rest of the years
}
float sinR(float angR){
    float tol=1e-6;
    if(angR>-tol&&angR<tol)return angR-angR*angR*angR/6;
    return 2*sinR(angR/2)*cosR(angR/2);
}
float cosR(float angR){
    float tol=1e-6;
    if(angR>-tol&&angR<tol)return 1-angR*angR/2;
    float a=cosR(angR/2);
    float b=sinR(angR/2);
    return a*a-b*b;
}

int max(int *a,int n){
    if(n==1)return a[0];
    int half=n/2;
    int top=n-half;
    int m1=max(a,half);
    int m2=max(a+half,top);
    return (m1>m2?m1:m2);
}
int sum(int *a,int n){
    if(n==0)return 0;
    if(n==1)return a[0];        // one thing left, we're done
    int half=n/2;               // cut the list in half
    int top=n-half;             // the other half
    int m1=sum(a,half);         // recurse the function
    int m2=sum(a+half,top);     // logN
    return (m1+m2);
}

void towers(int n,char source,char spare,char destination){
    if(n>1)towers(n-1,source,destination,spare);
    cout<<"Source = "<<source<<" move to "<<destination<<endl;
    if(n>1)towers(n-1,spare,source,destination);
}

int gcd(int m,int n){
    if(m==0) return n;
    if(m>=n) return gcd(m%n,n);
    if(m<n)  return gcd(n%m,m);
}

int bcoeff(int n,int k){
    if(k==0)return 1;
    if(k==n)return 1;
    return bcoeff(n-1,k-1)+bcoeff(n-1,k);
}