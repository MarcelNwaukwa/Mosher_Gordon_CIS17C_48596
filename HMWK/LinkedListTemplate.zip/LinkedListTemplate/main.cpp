/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on September 18, 2014, 1:55 PM
 * Purpose:  Explore creation of a linked list class Version 3
 * 
 * Modified by Gordon Mosher
 * for LnkdLst homework project
 * ver. 2014-1005
 * NOTE: Any type passed to template must override/support << and relational
 *      operators!
 */

//System Libraries
#include <iostream>
using namespace std;

//Our Library
#include "LnkdLst.h"
#include "FeetInches.h"

int main(int argc, char** argv) {
   // Define a LinkedList object.
   LnkdLst<FeetInches> FIList(0);

   // Define some FeetInches objects.
   FeetInches distance1(5, 4); // 5 feet 4 inches
   FeetInches distance2(6, 8); // 6 feet 8 inches
   FeetInches distance3(8, 9); // 8 feet 9 inches

   // Store the FeetInches objects in the list.
   // Note: my append is equivalent to Gaddis' appendNode
   FIList.append(distance1); // 5 feet 4 inches
   FIList.append(distance2); // 6 feet 8 inches
   FIList.append(distance3); // 8 feet 9 inches

   // Display the values in the list.
   // Note: my display is equivalent to Gaddis' displayList
   cout << "Here are the initial values:\n";
   FIList.display();
   cout << endl;

   // Insert another FeetInches object.
   // NOTE: I'm just using Gaddis' insertNode from the book
   cout << "Now inserting the value 7 feet 2 inches.\n";
   FeetInches distance4(7, 2);
   FIList.insertNode(distance4);

   // Display the values in the list.
   cout << "Here are the nodes now.\n";
   FIList.display();
   cout << endl;

   // Delete the last node.
   // NOTE: my extract is equivalent to Gaddis' deleteNode
   cout << "Now deleting the last node.\n";
   FeetInches distance5(8, 9);
   FIList.deleteNode(distance5);
   FIList.extract(distance2);

   // Display the values in the list.
   cout << "Here are the nodes left.\n";
   FIList.display();
   
   
    //Create a linked list
    LnkdLst<double> list(0);
    //Append 3 more chains
    int clinks=3;
    for(int i=1;i<=clinks;i++){
        cout << "Appending value " << i << endl;
        list.append(i);
    }
    //Print the data
    cout << "FIRST Data element in the list -> " << list.first() << endl;
    cout << "LAST  Data element in the list -> " << list.last() << endl;
    cout << endl;
    cout << "Prepending value 0" << endl;
    list.prepend(0);
    list.extract(2.2);
    cout << "Appending value 4" << endl;
    list.append(4);
    cout << endl;
    cout << "Insert  99 After 1.2" << endl;
    list.insertAfter(list.findLink(1.2),99);
    cout << "Insert  98 Before 3.2" << endl;
    list.insertBefore(list.findLink(3.2),98);
    cout << "Insert  97 Before FIRST" << endl;
    list.insertBefore(list.findLink(list.first()),97);
    cout << "Insert  96 After LAST" << endl;
    list.insertAfter(list.findLink(list.last()),96);
    cout << endl;
    cout<<list.toString()<<endl;
    LnkdLst<double> list2(list);// calls copy constructor
    LnkdLst<double> list3(0);   // regular constructor
//    LnkdLst<double> list4 = list3;// this initialization calls copy
                                    //constructor, not the overloaded operator =
    list3 = list2;               // list3 contents replaced by list2
    list3 += list2;              // list3 concat list2
    cout << "**** begin CRAZY ASSIGNMENT ****" << endl;
    list3 = list2 += list;      // works!
    cout << "**** end   CRAZY ASSIGNMENT ****" << endl;
//    LnkdLst<double> list4 = list;  // for some reason, this calls the copy constructor
    clinks=3;
    for(int i=1;i<=clinks;i++){
        cout << "Appending value " << i << endl;
        list2.append(i);
    }
    cout << "FIRST Data element in the list2 -> " << list2.first() << endl;
    cout << "LAST  Data element in the list2 -> " << list2.last() << endl;
    cout<<list2.toString()<<endl;
/*
    cout << "Tap spacebar to continue" << endl;
    cin.get();
*/
    //Exit stage right!
    // destructors will run now
    return 0;
}