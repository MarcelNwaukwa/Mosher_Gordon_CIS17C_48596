// *******************************************************
// File:        LnkdLst.cpp
// *******************************************************
// Project:     LinkedListStarter
// Programmer:  Gordon Mosher
// Instructor:  Mark Lehr
//
// Description: Implementation file for the LnkdLst class
//
// Version:     2014-0924
// *******************************************************
#include <iostream>
#include <string>
#include <stdio.h>        // for sprintf
#include <iomanip>       // for std::setw
using namespace std;
        
#include "LnkdLst.h"

// *******************************************************
// LnkdLst Contructor - default
// *******************************************************
/*
 * LnkdLst::LnkdLst() {
    head = NULL;
    tail = NULL;
    worker = NULL;
}
 */

// *******************************************************
// LnkdLst Contructor - overloaded
// *******************************************************
LnkdLst::LnkdLst(int optionalHead) {
    head = NULL;
    tail = NULL;
    worker = NULL;
//    this->head = (LnkdLst::Node*)optionalHead;
}

// *******************************************************
// LnkdLst Contructor - copy constructor
// *******************************************************
LnkdLst::LnkdLst(LnkdLst const& arg) {
    head = NULL;
    tail = NULL;
    worker = NULL;
//    this->head = (LnkdLst::Node*)optionalHead;
    Node* tmp;
    cout << "Copy Constructor\n";
    for (tmp = arg.head; tmp != 0; tmp = tmp->next) {
//      cout << "Constructing " << tmp->data << endl;
        append(tmp->data);
    }
}


// *******************************************************
// LnkdLst Destructor
// *******************************************************
LnkdLst::~LnkdLst() {
    char buffer[81];
    int counter = 0;
    if (head) {
        do {
            worker = head;
            head = head->next;
            sprintf(buffer, "  \tAddress & next = %x %x", worker, worker->next);
            cout << setw(3);
            cout << "Destroying Link " <<  setw(3) << ++counter << " Data = "
                    << setw(3) << worker->data << buffer << endl;
            delete worker;
//        } while (head && counter < 10);
        } while (head);
    }
    tail = NULL;
    cout << endl;
}





// *******************************************************
// LnkdLst first
// *******************************************************
int LnkdLst::first() {
    if (!head)
        return 0;       //throw domain_error("list is empty");
    return head->data;
}
// *******************************************************
// LnkdLst last
// *******************************************************
int LnkdLst::last() {
    if (!tail) {
        cout << "List is empty" << endl;
        return 0;       //throw domain_error("list is empty");
    }
    return tail->data;
}

// *******************************************************
// LnkdLst findLink
// *******************************************************
LnkdLst::Node* LnkdLst::findLink(int value) {
    worker = head;
    while (worker != 0 && worker->data != value)        // end or match
        worker = worker->next;
    if (worker == 0) {
        cout << "Value not found" << endl;
//        return NULL;
    }
    return worker;
}

// *******************************************************
// LnkdLst append
// *******************************************************
void LnkdLst::append(int value) {
    char buffer[81];
    Node* clink = new Node;
    clink->data = value;
    clink->next = NULL;
    if (!head) {                 // if no head, then this is head
        head = clink;
    }
    else {
        Node* nodeIndex = head;
        while (nodeIndex->next)         // zoom to end of list
            nodeIndex = nodeIndex->next;
        nodeIndex->next = clink;        // connect new node
    }
    tail = clink;
    cout << setw(3);
    sprintf(buffer, "  \tAddress & next = %x %x", clink, clink->next);
    cout << "Appending value  " << setw(3) << clink->data << " at " << buffer << endl;
}

// *******************************************************
// LnkdLst prepend
// *******************************************************
void LnkdLst::prepend(int value) {
    Node* clink = new Node;
    clink->data = value;
    clink->next = head;
    head = clink;
    if (!tail)
        tail = clink;
}

// *******************************************************
// LnkdLst extract
// *******************************************************
void LnkdLst::extract(int value) {
    Node* ptr = head;
    Node* prevPtr = 0;
    while (ptr != 0 && ptr->data != value) {
        prevPtr = ptr;
        ptr = ptr->next;
    }
    if (ptr == 0) {}    // value was NOT found
    if (ptr == head) {  // value was found at head
        head = ptr->next;       // set new head
    }
    else {
        prevPtr->next = ptr->next;      // point over item being extracted
    }
    if (ptr == tail) {
        tail = prevPtr;         // set new tail
    }
    cout << "Extracting value " << value << endl;
    delete ptr;
}
// *******************************************************
// LnkdLst insertAfter
// *******************************************************
void LnkdLst::insertAfter(Node *arg, int value) {
    
    Node* ptr = arg;

    if (ptr == 0) {
//      throw invalid_argument("invalid position");
        cout << "Failed to insertAfter - invalid position" << endl;
        return; //abend
    }
    
    Node* clink = new Node;
    clink->data = value;
    clink->next = ptr->next;    // ptr->next is REALLY where we want to be!
//  head will not be touched
    ptr->next = clink;
    if (tail == ptr)
        tail = clink;
}

// *******************************************************
// LnkdLst insertBefore
// *******************************************************
void LnkdLst::insertBefore(Node *arg, int value) {
    
    Node* ptr = arg;

    if (ptr == 0) {
//      throw invalid_argument("invalid position");
        cout << "Failed to insertBefore - invalid position" << endl;
        return; //abend
    }

    
    Node* clink = new Node;
    clink->data = value;
    clink->next = ptr;          // ptr is REALLY where we want to put it before!
    if (head == ptr)
        head = clink;
    else {
        Node* prevPtr = head;
        while (prevPtr != 0 && prevPtr->next != ptr)
            prevPtr = prevPtr->next;
        if (prevPtr == 0) {
    //      throw invalid_argument("invalid position");
            cout << "Failed to insertBefore - invalid position" << endl;
            delete clink;
            return; //abend
        }
        prevPtr->next = clink;
    }
//  tail will not be touched
}

// *******************************************************
// LnkdLst purge - like Destructor
// *******************************************************
void LnkdLst::purge() {
    char buffer[81];
    int counter = 0;
    if (head) {
        do {
            worker = head;
            head = head->next;
            sprintf(buffer, "  \tAddress & next = %x %x", worker, worker->next);
            cout << setw(3);
            cout << "Deleting link before operator ="
                    <<  setw(3) << ++counter << " Data = "
                    << setw(3) << worker->data << buffer << endl;
            delete worker;
//        } while (head && counter < 10);
        } while (head);
    }
    tail = NULL;
    cout << endl;
}

// *******************************************************
// LnkdLst toString
// *******************************************************
string LnkdLst::toString() {
    string outString = "";
    char buffer[81];
    if (head) {
        worker = head;
        do {
//works->   cout << "Data element in the list -> " << worker->data << endl;
/*
            outString = outString
                    + "Data element in the list -> "
                    + std::to_string(worker->data)
                    + '\n';                     // to_string is c++v11
*/
//            sprintf(buffer, "Data element in the list -> %d\n", worker->data);
            sprintf(buffer, "Data element in the list -> %3d  \tAddress + next = %x %x\n",
                    worker->data, worker, worker->next);
            outString += buffer;
        } while (worker = worker->next);        // assign and test
    }
    return outString;
}

