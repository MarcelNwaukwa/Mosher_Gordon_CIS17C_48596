/* 
 * File:   LnkdLst.h
 * Author: Dr. Mark E. Lehr
 * Created on September 18, 2014, 3:09 PM
 * 
 * Modified by Gordon Mosher
 * for LnkdLst homework project
 * ver. 2014-1004 make class LnkdLst a template
 *      tested for int, double, and class FeetInches
 * ver. 2014-1014 for Assignment 6
 *      added functions to support list, queue, and stack functionality
 * ver. 2014-1206 for Battleship Booty
 *      commented all #defines for extra function names, see notes at EOF
 */

#ifndef LNKDLST_H
#define	LNKDLST_H

#include <iostream>
#include <string>
#include <stdio.h>        // for sprintf
#include <iomanip>       // for std::setw
//#include "FeetInches.h"
using namespace std;
// #defines for Gaddis' compatability
#define LinkedList LnkdLst
#define ListNode Node
bool ccc = false;       // global debug flag for circular list
bool desDebug = false;
bool appendDebug = false;

template <class TYPE>
class LnkdLst {
private:
    static int listCount;
    class Node{         // or struct (no difference?)
    public:             // except data members are private by default
         TYPE data;
         Node *next;
         Node *prev;
    };
public:
    // constructors
    LnkdLst(int);
    LnkdLst(LnkdLst const&);    // COPY CONSTRUCTOR
//    void operator = (const LnkdLst & arg);
    // accessors
    static int getListCount(){return listCount;}  // inline static
    int getNodeCount() const {return nodeCount;}  // for list size p.1083
//#define size    getNodeCount
    TYPE first();
    TYPE last();
// stack function top Gaddis p.1083
//#define top     first
    LnkdLst<TYPE>::Node* findLink(TYPE);        // is this right?
    bool empty() const;         // stack function p.1083
    bool isFull() const;        // queue function p.1089
//#define isEmpty empty
    void display();
    string toString();
    // modifiers
    void append(TYPE);
    void prepend(TYPE);
// list functions Gaddis p.1059
//#define push_back       append
//#define push_front      prepend
    //void push_back (TYPE) { append(TYPE);}      // list function Gaddis p.1059
    //void push_front(TYPE) {prepend(TYPE);}      // list function Gaddis p.1059
// stack functions Gaddis p.1083
//#define push    prepend
// queue functions Gaddis p.1089  enqueue to tail, dequeue from head
//#define enqueue append
    void extract(TYPE searchValue);
    void pop(void);             // stack op. - pops the head
    void dequeue(TYPE &value);
    LnkdLst<TYPE>::Node* findAndPrioritizeLink(TYPE);
    void purge(void);
// clear is a purge function for queues Gaddis p.1089    
//#define clear   purge
    void insertBefore(Node *, TYPE);
    void insertAfter(Node *, TYPE);
    void insertNode(TYPE newValue);     // use these to maintain sorted list
    void deleteNode(TYPE searchValue);  // use these to maintain sorted list
    virtual ~LnkdLst();
private:
    Node *head;
    Node *tail;
    Node *worker;
    int nodeCount;
    int nodeSize;
public:
    // !!! OPERATOR OVERRIDES STAY INSIDE CLASS DECLARATION !!!
// *******************************************************
// LnkdLst Operator = similar to copy constructor
// *******************************************************

LnkdLst<TYPE>& operator = (const LnkdLst &right) {
    if (&right != this) {
        purge();
        cout << "Overloaded operator =\n";

        LnkdLst<TYPE>::Node* tmp;
        for (tmp = right.head; tmp != 0; tmp = tmp->next) {
    //      cout << "Constructing " << tmp->data << endl;
            append(tmp->data);
            if (tmp->next == right.head)
                tmp = NULL;                  // end of circular list
        }
    }
    return *this;
}
// *******************************************************
// LnkdLst Operator += similar to copy constructor
// *******************************************************

LnkdLst<TYPE>& operator += (const LnkdLst &right) {
    if (&right != this) {
//        purge();
        cout << "Overloaded operator +=\n";

        LnkdLst<TYPE>::Node* tmp;
        for (tmp = right.head; tmp != 0; tmp = tmp->next) {
    //      cout << "Constructing " << tmp->data << endl;
            append(tmp->data);
            if (tmp->next == right.head)
                tmp = NULL;                  // end of circular list
        }
    }

    return *this;
}
    
};      // END OF CLASS DECLARATION LnkdLst
template <class TYPE>
int LnkdLst<TYPE>::listCount = 0;  // NEEDED template syntax for STATIC members
                                   // because listCount is per TYPE!!!
                                   // static define outside class Gaddis p.827
// *******************************************************
// LnkdLst Contructor - overloaded
// *******************************************************
template <class TYPE>
LnkdLst<TYPE>::LnkdLst(int optionalHead) {
    head = NULL;
    tail = NULL;
    worker = NULL;
//    listCount++;
    cout << "listCount = " << ++listCount << endl;
    cout << "sizeof node = " << sizeof(TYPE) << endl;
    nodeCount = 0;
    nodeSize = sizeof(TYPE);
//    this->head = (LnkdLst::Node*)optionalHead;
}

// *******************************************************
// LnkdLst Contructor - copy constructor
// *******************************************************
template <class TYPE>
LnkdLst<TYPE>::LnkdLst(LnkdLst const& arg) {
    head = NULL;
    tail = NULL;
    worker = NULL;
    cout << "listCount = " << ++listCount << endl;
    cout << "sizeof node = " << sizeof(TYPE) << endl;
    nodeCount = 0;
    nodeSize = sizeof(TYPE);
//    this->head = (LnkdLst::Node*)optionalHead;
    Node* tmp;
    cout << "Copy Constructor\n";
    for (tmp = arg.head; tmp != 0; tmp = tmp->next) {
//      cout << "Constructing " << tmp->data << endl;
        append(tmp->data);
        if (tmp->next == arg.head)
            tmp = NULL;                  // end of circular list
    }
}


// *******************************************************
// LnkdLst Destructor
// *******************************************************
template <class TYPE>
LnkdLst<TYPE>::~LnkdLst() {
    char buffer[81];
    int counter = 0;
//    TYPE t;
    if (desDebug) cout << "in destructor" << endl;
    if (desDebug) cout << "listCount = " << listCount-- << endl;
    if (head) {
        do {
            worker = head;
            if (head->next == head)     // || !(head->next)
                head = NULL;            // end of circular list
            else
                head = head->next;      // as is for non-circular lists
            sprintf(buffer, "  \tAddress & next = %x %x", worker, worker->next);
            cout << setw(3);
            if (desDebug) {
                cout << "Destroying Link " 
                    << setw(3) 
                    << ++counter << " Data = "
                    << setw(3) 
                    << worker->data 
                    << buffer 
                    << endl;
            }
            delete worker;
//        } while (head && counter < 10);
        } while (head);
    }
    tail = NULL;
    nodeCount = 0;
    cout << endl;
}





// *******************************************************
// LnkdLst first
// *******************************************************
template <class TYPE>
TYPE LnkdLst<TYPE>::first() {
    if (!head)
        return 0;       //throw domain_error("list is empty");
    return head->data;
}
// *******************************************************
// LnkdLst last
// *******************************************************
template <class TYPE>
TYPE LnkdLst<TYPE>::last() {
    if (!tail) {
        cout << "List is empty" << endl;
        return 0;       //throw domain_error("list is empty");
    }
    return tail->data;
}

// *******************************************************
// LnkdLst findLink
// *******************************************************
template <class TYPE>
typename LnkdLst<TYPE>::Node* LnkdLst<TYPE>::findLink(TYPE value) {
    worker = head;
    while (worker != 0 && worker->data != value) {        // end or match
        worker = worker->next;
        if (worker == head) {
            worker = NULL;      // end of circular list
        }
    }
    if (worker == 0) {
        cout << "Value not found" << endl;
//        return NULL;
    }
    return worker;
}
// *******************************************************
// LnkdLst findAndPrioritizeLink
// *******************************************************
template <class TYPE>
typename LnkdLst<TYPE>::Node* LnkdLst<TYPE>::findAndPrioritizeLink(TYPE value) {
    worker = head;
    while (worker != 0 && worker->data != value) {        // end or match
        worker = worker->next;
        if (worker == head) {
            worker = NULL;      // end of circular list
        }
    }
    if (worker == 0) {
        cout << "Value not found" << endl;
//        return NULL;
    }
    else {      // prioritize it
        extract(value);
        prepend(value);
        worker = head;
    }
    return worker;
}
// *******************************************************
// LnkdLst empty and isEmpty
// *******************************************************
template <class TYPE>
bool LnkdLst<TYPE>::empty() const {
    if (!head)
        return true;    // list is empty
    else
        return false;
}
// *******************************************************
// LnkdLst isFull
// *******************************************************
template <class TYPE>
bool LnkdLst<TYPE>::isFull() const {
    return false;       // can't be full, it's a linked list
}

// *******************************************************
// LnkdLst append
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::append(TYPE value) {
    char buffer[81];
    Node* clink = new Node;
    nodeCount++;
    if (appendDebug) cout << "NodeCount = " << nodeCount << endl;
    clink->data = value;// +.2;
    clink->next = NULL;
    if (!head) {                 // if no head, then this is head
        head = clink;
if(ccc==true)        clink->next = head;     // circular list
        tail = clink;
        clink->prev = tail;     // circular list
    }
    else {
        Node* nodeIndex = head;
        while ((nodeIndex->next) && (nodeIndex->next != head) )         // zoom to end of circular list
            nodeIndex = nodeIndex->next;
        nodeIndex->next = clink;        // connect new node
if(ccc==true)        clink->next = head;             // circular list
        tail = clink;                   // append is at the tail
        clink->prev = nodeIndex;
    }
    cout << setw(3);
    sprintf(buffer, "  \tAddress & next, prev = %x %x %x", clink, clink->next, clink->prev);
    cout << "Appending value  " << setw(3) << clink->data << " at " << buffer << endl;
}

// *******************************************************
// LnkdLst prepend
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::prepend(TYPE value) {
    Node* clink = new Node;
    nodeCount++;
    if (appendDebug) cout << "NodeCount = " << nodeCount << endl;
    clink->data = value;
    clink->next = head;         // NULL if list was empty
    head = clink;
    if (ccc==true && clink->next == NULL)
        clink->next = head;    // circular list
    if (!tail)
        tail = clink;
    clink->prev = tail;         // prepend is always at the head
}

// *******************************************************
// LnkdLst extract
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::extract(TYPE value) {
    Node* ptr = head;
    Node* prevPtr = 0;
    while (ptr != 0 && ptr->data != value) {
        prevPtr = ptr;
        ptr = ptr->next;
        if (ptr == head)
            ptr = NULL;                 // end of circular list
    }
    if (ptr == 0) {
        //      throw invalid_argument("invalid position");
        cout << "Failed to extract - invalid position" << endl;
        return; //abend
    }
    if (ptr == head) {  // value was found at head
        head = ptr->next; // set new head (could be NULL) never NULL in circular
    }
    else {
        prevPtr->next = ptr->next;      // point over item being extracted
    }
    if (ptr == tail) {
        tail = prevPtr;         // set new tail
    }
    cout << "Extracting value " << value << endl;
    delete ptr;
    nodeCount--;
}
// *******************************************************
// LnkdLst pop
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::pop(void) {
    Node* ptr = head;
    Node* prevPtr = 0;
/*
    while (ptr != 0 && ptr->data != value) {
        prevPtr = ptr;
        ptr = ptr->next;
    }
*/
    if (ptr == 0) {
        //      throw invalid_argument("invalid position");
        cout << "Failed to extract - invalid position" << endl;
        return; //abend
    }
    if (ptr == head) {  // value was found at head
        head = ptr->next; // set new head (could be NULL) never NULL in circular
    }
    else {
        prevPtr->next = ptr->next;      // point over item being extracted
    }
    if (ptr == tail) {
        tail = prevPtr;         // set new tail
    }
//    cout << "Extracting value " << value << endl;
    cout << "Popping stack" << endl;
    delete ptr;
    nodeCount--;
}
// *******************************************************
// LnkdLst dequeue
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::dequeue(TYPE &value) {
    Node* ptr = head;
    Node* prevPtr = 0;
/*
    while (ptr != 0 && ptr->data != value) {
        prevPtr = ptr;
        ptr = ptr->next;
    }
*/
    if (ptr == 0) {
        //      throw invalid_argument("invalid position");
        cout << "Failed to extract - invalid position" << endl;
        return; //abend
    }
    if (ptr == head) {  // value was found at head
        value = head->data;     // popping this value from the head
        head = ptr->next; // set new head (could be NULL) never NULL in circular
    }
    else {
        prevPtr->next = ptr->next;      // point over item being extracted
    }
    if (ptr == tail) {
        tail = prevPtr;         // set new tail
    }
//    cout << "Extracting value " << value << endl;
    cout << "Dequeueing value " << value << endl;
    delete ptr;
    nodeCount--;
}
// *******************************************************
// LnkdLst insertAfter
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::insertAfter(Node *arg, TYPE value) {
    
    Node* ptr = arg;

    if (ptr == 0) {
//      throw invalid_argument("invalid position");
        cout << "Failed to insertAfter - invalid position" << endl;
        return; //abend
    }
    
    Node* clink = new Node;
    nodeCount++;
    if (appendDebug) cout << "NodeCount = " << nodeCount << endl;
    clink->data = value;
    clink->next = ptr->next;    // ptr->next is REALLY where we want to be!
//  head will not be touched
    ptr->next = clink;
    if (tail == ptr)
        tail = clink;
}

// *******************************************************
// LnkdLst insertBefore
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::insertBefore(Node *arg, TYPE value) {
    
    Node* ptr = arg;

    if (ptr == 0) {
//      throw invalid_argument("invalid position");
        cout << "Failed to insertBefore - invalid position" << endl;
        return; //abend
    }

    
    Node* clink = new Node;
    nodeCount++;
    if (appendDebug) cout << "NodeCount = " << nodeCount << endl;
    clink->data = value;
    clink->next = ptr;          // ptr is REALLY where we want to put it before!
    if (head == ptr)
        head = clink;
    else {
        Node* prevPtr = head;
        while (prevPtr != 0 && prevPtr->next != ptr)
            prevPtr = prevPtr->next;
        if (prevPtr == 0) {
    //      throw invalid_argument("invalid position");
            cout << "Failed to insertBefore - invalid position" << endl;
            delete clink;
            return; //abend
        }
        prevPtr->next = clink;
    }
//  tail will not be touched
}

// *******************************************************
// LnkdLst purge - like Destructor
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::purge() {
    char buffer[81];
    int counter = 0;
    if (head) {
        do {
            worker = head;
            if (head->next == head)     // || !(head->next)
                head = NULL;            // end of circular list
            else
                head = head->next;      // as is for non-circular lists
            sprintf(buffer, "  \tAddress & next = %x %x", worker, worker->next);
            cout << setw(3);
            cout << "Deleting link (purge) before operator ="
                    << setw(3) << ++counter << " Data = "
                    << setw(3) << worker->data << buffer << endl;
            delete worker;
//        } while (head && counter < 10);
        } while (head);
    }
    tail = NULL;
    nodeCount = 0;
    cout << endl;
}

// *******************************************************
// LnkdLst display
// *******************************************************
template <class TYPE>
void LnkdLst<TYPE>::display() {
    if (head) {
        worker = head;
        do {
            cout << worker->data << endl;//works->
            if (worker->next == head)
                break;                  // end of circular list
        } while (worker = worker->next);        // assign and test
    }
}

// *******************************************************
// LnkdLst toString
// *******************************************************
template <class TYPE>
string LnkdLst<TYPE>::toString() {
    string outString = "";
    char buffer[81];
    if (head) {
        worker = head;
        do {
            cout << "Data element in the list -> " << worker->data << endl;//works->
/*
            outString = outString
                    + "Data element in the list -> "
                    + std::to_string(worker->data)
                    + '\n';                     // to_string is c++v11
*/
//old            sprintf(buffer, "Data element in the list -> %d\n", worker->data);
//new            sprintf(buffer, "Data element in the list -> %3d  \tAddress + next = %x %x\n",
//new                    worker->data, worker, worker->next);
//new            outString += buffer;
            if (worker->next == head)
                break;                  // end of circular list
        } while (worker = worker->next);        // assign and test
    }
    return outString;
}
// Gaddis code from here down
//**************************************************
// The insertNode function inserts a node with     *
// newValue copied to its value member.            *
//**************************************************

template <class T>
void LinkedList<T>::insertNode(T newValue)
{
   ListNode *newNode;             // A new node
   ListNode *nodePtr;             // To traverse the list
   ListNode *previousNode = NULL; // The previous node

   // Allocate a new node and store newValue there.
   newNode = new ListNode;
    nodeCount++;
    if (appendDebug) cout << "NodeCount = " << nodeCount << endl;
   newNode->data = newValue;
   
   // If there are no nodes in the list
   // make newNode the first node
   if (!head)
   {
      head = newNode;
      newNode->next = NULL;
   }
   else  // Otherwise, insert newNode
   {
      // Position nodePtr at the head of list.
      nodePtr = head;

      // Initialize previousNode to NULL.
      previousNode = NULL;

      // Skip all nodes whose value is less than newValue.
      while (nodePtr != NULL && nodePtr->data < newValue)
      {  
         previousNode = nodePtr;
         nodePtr = nodePtr->next;
      }

      // If the new node is to be the 1st in the list,
      // insert it before all other nodes.
      if (previousNode == NULL)
      {
         head = newNode;
         newNode->next = nodePtr;
      }
      else  // Otherwise insert after the previous node.
      {
         previousNode->next = newNode;
         newNode->next = nodePtr;
      }
   }
}

//*****************************************************
// The deleteNode function searches for a node        *
// with searchValue as its value. The node, if found, *
// is deleted from the list and from memory.          *
//*****************************************************

template <class T>
void LinkedList<T>::deleteNode(T searchValue)
{
   ListNode *nodePtr;       // To traverse the list
   ListNode *previousNode;  // To point to the previous node

   // If the list is empty, do nothing.
   if (!head)
      return;
   
   // Determine if the first node is the one.
   if (head->data == searchValue)
   {
      nodePtr = head->next;
      delete head;
      nodeCount--;
      head = nodePtr;
   }
   else
   {
      // Initialize nodePtr to head of list
      nodePtr = head;

      // Skip all nodes whose value member is 
      // not equal to num.
      while (nodePtr != NULL && nodePtr->data != searchValue)
      {  
         previousNode = nodePtr;
         nodePtr = nodePtr->next;
      }

      // If nodePtr is not at the end of the list, 
      // link the previous node to the node after
      // nodePtr, then delete nodePtr.
      if (nodePtr)
      {
         previousNode->next = nodePtr->next;
         delete nodePtr;
         nodeCount--;
      }
   }
}
#endif	/* LNKDLST_H */

/*
 * ALSO COMMENTED #defines for:
 * enqueue      append
 * push_front   prepend
 * isEmpty      empty
 * size         getNodeCount
 * 
 * "/c/mingw/msys/1.0/bin/make.exe" -f nbproject/Makefile-Debug.mk QMAKE= SUBPROJECTS= .build-conf
make.exe[1]: Entering directory `/f/NC2014Fall/CIS-17C/BattleshipBooty'
"/c/mingw/msys/1.0/bin/make.exe"  -f nbproject/Makefile-Debug.mk dist/Debug/MinGW-Windows/battleshipbooty.exe
make.exe[2]: Entering directory `/f/NC2014Fall/CIS-17C/BattleshipBooty'
mkdir -p build/Debug/MinGW-Windows
rm -f build/Debug/MinGW-Windows/main.o.d
g++    -c -g -MMD -MP -MF build/Debug/MinGW-Windows/main.o.d -o build/Debug/MinGW-Windows/main.o main.cpp
main.cpp: In function 'int main(int, char**)':
In file included from main.cpp:36:0:
LnkdLst.h:66:17: error: 'class std::stack<int>' has no member named 'prepend'
 #define push    prepend
                 ^
main.cpp:252:21: note: in expansion of macro 'push'
             s[col]->push(shipGrid[row*10+col]);
                     ^
LnkdLst.h:61:25: error: 'class std::vector<int>' has no member named 'append'
 #define push_back       append
                         ^
main.cpp:257:16: note: in expansion of macro 'push_back'
             v1.push_back(s[col]->top());
                ^
LnkdLst.h:50:17: error: 'class std::stack<int>' has no member named 'first'
 #define top     first
                 ^
main.cpp:257:34: note: in expansion of macro 'top'
             v1.push_back(s[col]->top());
                                  ^
LnkdLst.h:75:17: error: 'class std::vector<int>' has no member named 'purge'
 #define clear   purge
                 ^
main.cpp:261:12: note: in expansion of macro 'clear'
         v1.clear();     // don't clear if <pointer>
            ^
LnkdLst.h:66:17: error: 'class std::queue<int>' has no member named 'prepend'
 #define push    prepend
                 ^
main.cpp:267:21: note: in expansion of macro 'push'
             q[row]->push(shipGrid[row*10+col]);
                     ^
LnkdLst.h:61:25: error: 'class std::vector<int>' has no member named 'append'
 #define push_back       append
                         ^
main.cpp:272:16: note: in expansion of macro 'push_back'
             v2.push_back(q[row]->front());
                ^
LnkdLst.h:75:17: error: 'class std::vector<int>' has no member named 'purge'
 #define clear   purge
                 ^
main.cpp:276:12: note: in expansion of macro 'clear'
         v2.clear();     // don't clear if <pointer>
            ^
make.exe[2]: *** [build/Debug/MinGW-Windows/main.o] Error 1
make.exe[2]: Leaving directory `/f/NC2014Fall/CIS-17C/BattleshipBooty'
make.exe[1]: *** [.build-conf] Error 2
make.exe[1]: Leaving directory `/f/NC2014Fall/CIS-17C/BattleshipBooty'
make.exe": *** [.build-impl] Error 2


BUILD FAILED (exit value 2, total time: 9s)
 * 
 */