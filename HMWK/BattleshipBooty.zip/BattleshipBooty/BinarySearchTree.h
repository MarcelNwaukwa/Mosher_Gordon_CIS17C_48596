/* 
 * File:   BinarySearchTree.h
 * Author: Dave
 *
 * Created on November 27, 2014, 11:14 PM
 */

#ifndef BINARYSEARCHTREE_H
#define	BINARYSEARCHTREE_H

#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include <ctime>        // for time(0)
#include <cmath>        // log()
#include <vector>
#include <algorithm>    // random_shuffle
#include <typeinfo>     // typeid
//#include <random>

using namespace std;

// =============================================================================
// Source for BinarySearchTree.h
template <class TYPE>
class BinarySearchTree {
public:
    static int nodeCount;
private:
    struct Node {
        TYPE value;
        Node *left;
        Node *right;
    };
    Node *root;
    int maxDepth;       // updated by checkDepth...()
    
    // Private member functions
    void insert(Node *&, Node *&);
    void destroySubTree(Node *);
    void deleteNode(TYPE, Node *&);
    void makeDeletion(Node *&);
    void balance(Node *&);      // only works for root
    int checkDepthInOrder(Node *, char, int);
    void displayInOrder(Node *, char, int) const;
    void displayPreOrder(Node *) const;
    void displayPostOrder(Node *) const;
    
public:
    BinarySearchTree() {root = NULL;}           // Constructor
    ~BinarySearchTree() {destroySubTree(root);} // Destructor
    
    // Binary tree operations
    void insertNode(TYPE);
    bool searchNode(TYPE);
    void remove(TYPE);
    void balance()
        { balance(root); };
    int checkDepthInOrder()               // no params overload is public
        { maxDepth = 0; return checkDepthInOrder(root, '=', 0)-1; }
    void displayInOrder() const
        { displayInOrder(root, '=', 0); }  // 0 is depth of branch, 0 for =root
    void displayPreOrder() const
        { displayPreOrder(root); }
    void displayPostOrder() const
        { displayPostOrder(root); }
};
template <class TYPE>
int BinarySearchTree<TYPE>::nodeCount = 0;
//#endif	/* BINARYSEARCHTREE_H */
// =============================================================================
// Source for BinarySearchTree<TYPE>.cpp
template <class TYPE>
void BinarySearchTree<TYPE>::insertNode(TYPE Tvalue) {
    Node *newNode;      // automatic pointer to new node
    
    newNode = new Node;         // create the node on the heap
    newNode->value = Tvalue;
    newNode->left = NULL;       // because new nodes are all leaves
    newNode->right = NULL;
    insert(root, newNode);      // insert the node into the tree at root
        // root is a reference parameter, so it's modifiable
        // and will be set to newNode if the tree is empty
        // otherwise newNode will recursively look down the
        //      left or right branches till it finds a NULL
    nodeCount++;
}

template <class TYPE>
void BinarySearchTree<TYPE>::insert(Node *&nodePtr, Node *&newNode) {
    if (nodePtr == NULL) {
        nodePtr = newNode;
    }
    else if (newNode->value < nodePtr->value) {
        insert(nodePtr->left, newNode);         // look left
    }
    else {
        insert(nodePtr->right, newNode);        // look right
    }
}
template <class TYPE>
void BinarySearchTree<TYPE>::destroySubTree(Node *nodePtr) {  // called by Destructor
    if (nodePtr)                                         // it's recursive
    {
       if (nodePtr->left)
          destroySubTree(nodePtr->left);         // go left first
       if (nodePtr->right)
          destroySubTree(nodePtr->right);        // then go right
       delete nodePtr;                           // finally whack the node
       nodeCount--;
    }
}
template <class TYPE>
bool BinarySearchTree<TYPE>::searchNode(TYPE Tvalue) {
    Node *nodePtr = root;

    while (nodePtr)
    {
       if (nodePtr->value == Tvalue)
          return true;
       else if (Tvalue < nodePtr->value)
          nodePtr = nodePtr->left;
       else
          nodePtr = nodePtr->right;
    }
    return false;
}
template <class TYPE>
void BinarySearchTree<TYPE>::remove(TYPE Tvalue) {
    deleteNode(Tvalue, root);
}
template <class TYPE>
void BinarySearchTree<TYPE>::deleteNode(TYPE Tvalue, Node *&nodePtr)
{
    bool debug = false;
    if (debug) cout << "." << endl;
    if (nodePtr == NULL) {
        cout << "Cannot delete empty node.\n";
    }
    else if (Tvalue < nodePtr->value) {
        if (debug) cout << "L(" << nodePtr->value << ")\n";
        deleteNode(Tvalue, nodePtr->left);
    }
    else if (Tvalue > nodePtr->value) {
        if (debug) cout << "R\n";
        deleteNode(Tvalue, nodePtr->right);
    }
    else {
        if (debug) cout << "*makeDEL*\n";
        makeDeletion(nodePtr);
    }
}
//***********************************************************
// makeDeletion takes a reference to a pointer to the node  *
// that is to be deleted. The node is removed and the       *
// branches of the tree below the node are re-attached.     *
// code learned in GaddiS Chapter 20 page 1160              *
//***********************************************************
template <class TYPE>
void BinarySearchTree<TYPE>::makeDeletion(Node *&nodePtr) {
    Node *tempNodePtr;                       // for attaching left tree

    if (nodePtr == NULL)
       cout << "Cannot delete empty node.\n";
    else if (nodePtr->right == NULL) {
       tempNodePtr = nodePtr;
       nodePtr = nodePtr->left;                  // Re-attach the left child
       delete tempNodePtr;
       nodeCount--;
    }
    else if (nodePtr->left == NULL) {
       tempNodePtr = nodePtr;
       nodePtr = nodePtr->right;  // Re-attach the right child
       delete tempNodePtr;
       nodeCount--;
    }
    // If the node has two children.
    else {
       // Move one node the right.
       tempNodePtr = nodePtr->right;
       // Go to the end left node.
       while (tempNodePtr->left)
          tempNodePtr = tempNodePtr->left;
       // Re-attach the left subtree.
       tempNodePtr->left = nodePtr->left;

       tempNodePtr = nodePtr;
       // Re-attach the right subtree.
       nodePtr = nodePtr->right;
       delete tempNodePtr;
       nodeCount--;
    }
}
template <class TYPE>
void BinarySearchTree<TYPE>::balance(Node *&nodePtr) {      // only works for root
    vector<TYPE> vTval;
    if (nodeCount < 10)
        return;                         // not enough elements to balance
    bool debug = false;
    int holdNodeCount = nodeCount;
    cout << "\nBalancing tree.\n";
//    for (int i = 0; i < nodeCount; i++) {
    while (nodeCount > 0) {                  // flatten the tree to a vector
        vTval.push_back(nodePtr->value);
        remove(nodePtr->value);
    }
    cout << "\nSort to cherry pick strong trunk.\n";
    sort(vTval.begin(), vTval.end());   // sort the list
    for (typename vector<TYPE>::iterator it=vTval.begin(); it!=vTval.end(); ++it)
        if (debug) cout << *it << endl;    
    // hand pick 7 items to build a strong trunk
    cout << "Cherry pick 7 elements to build a strong trunk.\n";
    int loc;
    loc = floor(vTval.size() * .50);          // midpoint
    insertNode(vTval[loc]);
    cout << vTval[loc] << "(.50) ";
    vTval.erase(vTval.begin()+loc);
    loc = floor(vTval.size() * .25);          // midpoint
    insertNode(vTval[loc]);
    cout << vTval[loc] << "(.25) ";
    vTval.erase(vTval.begin()+loc);
    loc = floor(vTval.size() * .75);          // midpoint
    insertNode(vTval[loc]);
    cout << vTval[loc] << "(.75) ";
    vTval.erase(vTval.begin()+loc);
    loc = floor(vTval.size() * .125);          // midpoint
    insertNode(vTval[loc]);
    cout << vTval[loc] << "(.125) ";
    vTval.erase(vTval.begin()+loc);
    loc = floor(vTval.size() * .875);          // midpoint
    insertNode(vTval[loc]);
    cout << vTval[loc] << "(.875) ";
    vTval.erase(vTval.begin()+loc);
    loc = floor(vTval.size() * .375);          // midpoint
    insertNode(vTval[loc]);
    cout << vTval[loc] << "(.375) ";
    vTval.erase(vTval.begin()+loc);
    loc = floor(vTval.size() * .625);          // midpoint
    insertNode(vTval[loc]);
    cout << vTval[loc] << "(.625) ";
    vTval.erase(vTval.begin()+loc);
    cout << "\nShuffle remaining data to more evenly build branches and leaves.\n";
//    shuffle(vTval.begin(), vTval.end(), default_random_engine(time(0)));   // randomize the list
    random_shuffle(vTval.begin(), vTval.end());   // randomize the list
    while (nodeCount < holdNodeCount/*+7*/) {
        if (debug) cout << vTval.back() << endl;
        insertNode(vTval.back());
        vTval.pop_back();
    }
}
template <class TYPE>
int BinarySearchTree<TYPE>::checkDepthInOrder(Node *nodePtr, char dirChar, int depth) {
    bool debug = true;
//    static int depth = 1;
    if (depth > maxDepth)
        maxDepth = depth;
    static string sTab = "\t\t\t\t\t\t\t\t\t\t";
    if (nodePtr) {
        if (debug) cout << dirChar << "(" << nodePtr->value << ")\n";
//        depth++;
        /*if (nodePtr->left)*/ checkDepthInOrder(nodePtr->right, 'R', depth+1);
        cout << "------->" << sTab.substr(0, depth) << '"' << nodePtr->value
                << "\" (depth=" << depth << ")" << endl;
        /*if (nodePtr->right)*/ checkDepthInOrder(nodePtr->left, 'L', depth+1);
    }
    else {
        if (debug) cout << dirChar << "(NULL)\n";
//        depth--;
    }
    return maxDepth;    // not necessary to return it, it's global to the class
}
template <class TYPE>
void BinarySearchTree<TYPE>::displayInOrder(Node *nodePtr, char dirChar, int depth) const {
    bool debug = false;
    char quoteCharL = '"', quoteCharR = '"';
/*
    cout << typeid(nodePtr->left).name() << endl;
    if (typeid(nodePtr->value).name() != "Ss")  // Ss is for string ???
        quoteCharL = quoteCharR = '"';
    else { quoteCharL = '['; quoteCharR = ']'; } // prefer []
*/
//    static int depth = 1;
    static string sTab = "\t\t\t\t\t\t\t\t\t\t";
    if (nodePtr) {
        if (debug) cout << dirChar << "(" << nodePtr->value << ")\n";
//        depth++;
        /*if (nodePtr->left)*/ displayInOrder(nodePtr->left, 'L', depth+1);
        cout << "------->" << sTab.substr(0, depth) 
                << quoteCharL << nodePtr->value
                << quoteCharR << " (depth=" << depth << ")" << endl;
        /*if (nodePtr->right)*/ displayInOrder(nodePtr->right, 'R', depth+1);
    }
    else {
        if (debug) cout << dirChar << "(NULL)\n";
//        depth--;
    }
}
template <class TYPE>
void BinarySearchTree<TYPE>::displayPreOrder(Node *nodePtr) const {
    if (nodePtr) {
        cout << nodePtr->value << endl;
        displayPreOrder(nodePtr->left);
        displayPreOrder(nodePtr->right);
    }
}
template <class TYPE>
void BinarySearchTree<TYPE>::displayPostOrder(Node *nodePtr) const {
    if (nodePtr) {
        displayPostOrder(nodePtr->left);
        displayPostOrder(nodePtr->right);
        cout << nodePtr->value << endl;
    }
}
#endif	/* BINARYSEARCHTREE_H */
