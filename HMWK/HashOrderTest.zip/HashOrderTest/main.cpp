/* 
 * File:   main.cpp
 * Author: Dave
 *
 * Created on October 26, 2014, 7:57 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip> // for setw
#include <ctime>

using namespace std;

class hashLink {
public:
    string key;
    hashLink *next;
};
class hashSlot {
public:
    hashLink *head;
};


void memorySizeTests_StackAndHeap() {
    int MAX_SIZE = 100;
    int *pI[MAX_SIZE];
    unsigned long BIG_NUMBER = 10000000; // was 10^8 in demo
//    int pI4[500000];  // 4 * 500,000 (couldn't do 4 * 1e6)// STACK = 2MB
    int *pI2[100];
    int count=0;
    string *sa[100];    // an array of string pointers  
                        // 4 bytes * 500,000 = fills 2MB stack
//http://stackoverflow.com/questions/2365156/adding-string-objects-to-an-array-via-loop
    
    //default initial string size is 
    string sString;
    cout << "Capacity: " << sString.capacity() << endl;
    sString = "";
    sString.reserve(20);
    cout << "Capacity: " << sString.capacity() << endl;
    sString = "A";
    cout << "Capacity: " << sString.capacity() << endl;
    sString = "12345678901234567890";
    cout << "Capacity: " << sString.capacity() << endl;
    sString = "A";
    cout << "Capacity: " << sString.capacity() << endl;

    
    
    cout << "sizeof(sa) = " << sizeof(sa) << endl;
    
    int *pI3 = new int[BIG_NUMBER];
    cout << "sizeof = " << sizeof(int)*BIG_NUMBER << endl;      
                        // 40 MB * 50 = 2GB HEAP like at 32bit OS
    
    // IF STACK OVERFLOWS, RUN FAILED exit value -1,073,741,571
    // stack size is set by OS not C++, size can be set in DEV ENVI options?
    
    for (int i=0;i<MAX_SIZE;i++) {
        sa[i] = new string("");//"                    ");
        cout << "Capacity: " << (*sa[i]).capacity() << " ";
        pI[i] = new int[BIG_NUMBER];
        cout << count++ << " " << sizeof(pI) << " " << sizeof(pI2) 
                << "x" << sizeof(*(pI[i])) << "x "  ;
        if (i % 10 == 9) cout << endl;
    }
    cout << "done" << endl;
    return;
}
void memorySizeTests_HeapOnly() {
    int min_N = 100;
    int max_N = 3e7;
    // at max_N = 3e7, array takes 4 bytes * 3e7 = 120 MB
    // at max_N = 3e7, strings take 20 chars * 3e7 = 600 MB
    // total = 720 MB, really takes about 1.5 GB from Operation System
    // as seen in System Monitor
    // each loop takes about 24 seconds to alloc,fill,delete (no sort or search)
    for (int N = max_N; N <= max_N +10; N += 1) {
        
        cout << "Allocating array..." << endl;
        string *sa = new string[N];     // allocate N string pointers on heap
                                        // keeps the array off the stack
                                        // easy to delete and resize
        cout << "New loop N = " << N << endl;
        cout << "Filling array..." << endl;
        for (int i = 0; i < N; i++) {
            if (!(i%1000000)) cout << ".";
            sa[i] = "12345678901234567890";     // 20 chars per string
//            cout << "Capacity: " << sa[i].capacity();
        }
        
        cout << sa[50] << endl;
//        for (int i = 0; i < N; i++) {
//            delete sa[i];
//        }
        cout << "Deleting array..." << endl;
        delete[] sa;
        cout << "deleted." << endl << endl;
//        cout << sa[50] << endl;
    }
    return;
}
void fillArray(string *sa, int N) {
    string tmpString = "12345678901234567890";  // initial capacity 20 chars
    
    for (int i = 0; i < N; i++) {
        if (!(i%(int)1e7)) cout << ".";
        tmpString = "";
        for (int j = 0; j < 20; j++) {
            tmpString += 'a' + rand()%26+0;
        }
//            sa[i] = "12345678901234567890";     // 20 chars per string
        sa[i] = tmpString;
//            cout << "Capacity: " << sa[i].capacity();
    }
    cout << endl;     // for "." 5 lines up
    return;
}
#define hashExpr (((s[0] - 'a') * 26*26*26) + ((s[1] - 'a') * 26*26) + ((s[2] - 'a') * 26) + (s[3] - 'a'))
int hashItem(string s) {
//**/    cout << "hash:" << s[0] << s[1] << (((s[0]-'a') * 26) + (s[1] - 'a'))<<endl;
//    return (((s[0]-'a') * 26) + (s[1] - 'a'));
    return (((s[0] - 'a') * 26*26*26) + 
            ((s[1] - 'a') * 26*26) +
            ((s[2] - 'a') * 26) +
             (s[3] - 'a'));
}
void insertItem(hashSlot *hs, string s) {
    int location = hashItem(s);
    hashLink *clink = new hashLink;
    clink->key = s;
    clink->next = hs[location].head;
    hs[location].head = clink;    
//**/    if (location == 0) cout << "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD";
}
void fillHashTable(hashSlot *hs, string *sa, int N) {
    for (int i = 0; i < N; i++) {
//        cout << "hashfillloop" << i;
        insertItem(hs, sa[i]);
    }
}
void purgeHashTable(hashSlot *hs) {
    hashLink *worker;
    int msgCount = 0;
    
    for (int i = 0; i < 26 * 26 * 26 * 26; i++) { // 676*676 slots
        if (hs[i].head && msgCount < 5) {     // only show first 5 nonzero heads
            msgCount++;
            cout << "Purge:" << i << " " << hs[i].head << " ";
            if (hs[i].head) cout << hs[i].head->next << endl; else cout << endl;
            // this could be a workerhead and show all next while head
        }
        if (hs[i].head) {    // head
            do {
//                cout << ".";  // << endl;     // be careful c/b 1e7 dots
                worker = hs[i].head;
                hs[i].head = hs[i].head->next;
                delete worker;
            } while (hs[i].head);
        }
//        cout << endl;    // for dots above
    }
}
void setupSearchData(string *sa, int N, string *searchData, int max_SD) {
    for (int i = 0; i < max_SD/2; i++) {
        // keep max_SD an even number ONLY TESTED FOR 10
        // fill half the searchData with data in the list
//            cout << N << " " << i * (N-1)/4 << " " << i * ((N-1)/4) << endl;
        string tmpString = sa[i * (N-1)/4];     // quarter the list
//            string tmpString = "12345678901234567890";
//            cout << "i=" << i << " " << tmpString << endl;
        searchData[i] = tmpString;
        // fill the 2nd half of the searchData with data NOT in the list
        searchData[i + max_SD/2] = tmpString;
        searchData[i + max_SD/2].replace(18, 2, "X0");//Gaddis p597
    }
    return;
}
void display(const string &arrayName, string *sa, int count) {
    for(int i = 0; i < count; i++) {
        string s = sa[i];
        cout << arrayName << "[" << i << "] = " << sa[i] << " "
        << "hash:" << s[0] << s[1] << s[2] << s[3] << hashExpr
//        << "hash:" << s[0] << s[1] << (((s[0]-'a') * 26) + (s[1] - 'a'))
        << endl;
    }
}
void bubbleSort(string *sa,int N){
    for(int i=0;i<N-1;i++){
        for(int j=i+1;j<N;j++){
            if(sa[i]>sa[j]){
                string temp=sa[i];
                sa[i]=sa[j];
                sa[j]=temp;
            }
        }
    }
}
void swap(string &value1, string &value2) {
    string temp = value1;
    value1 = value2;
    value2 = temp;
}
int partition(string set[], int start, int end) {
    string pivotValue;
    int pivotIndex, mid;
    
    mid = (start + end) / 2;
    swap(set[start], set[mid]);
    pivotIndex = start;
    pivotValue = set[start];
    for (int scan = start + 1; scan <= end; scan++) {
        if (set[scan] < pivotValue) {
            pivotIndex++;
            swap(set[pivotIndex], set[scan]);
        }
    }
    swap(set[start], set[pivotIndex]);
    return pivotIndex;
}
void quickSort(string set[], int start, int end) {
    int pivotPoint;
    
    if (start < end) {
        // Get the pivot point.
        pivotPoint = partition(set, start, end);
        // Sort the first sublist
        quickSort(set, start, pivotPoint - 1);
        // Sort the second sublist.
        quickSort(set, pivotPoint + 1, end);
    }
}
int linearSearch(string *sa, int N, string searchString) {  // Gaddis p.468
    int index = 0;
    int position = -1;
    bool found = false;
    
    while (index < N && !found) {
        if (sa[index] == searchString) {   // we only passed in one searchData
            found = true;
            position = index;
        }
        index++;
    }
    if (found) cout << "X"; else cout << "O";
    return position;
}
int time_10_linearSearches(string *sa, int N, string *searchData, int max_SD) {
    clock_t seek_start = clock();
    cout << "Linear Seek results = ";
    for (int i = 0; i < max_SD; i++) {
        linearSearch(sa, N, searchData[i]);
    }
    clock_t totalTime = clock() - seek_start;
    cout << endl;       // for X's and O's
    return totalTime;
}
int binarySearch(string *sa, int N, string searchString, int iter){//Gaddis p471
    int first = 0;
    int last = N-1;
    int middle;
    int position = -1;
    bool found = false;
    
    while (!found && first <= last) {
        middle = (first + last) / 2;
        if (sa[middle] == searchString) {   // we only passed in one searchData
            found = true;
            position = middle;
        }
        else if (sa[middle] > searchString)
            last = middle - 1;
        else
            first = middle + 1;
    }
    if (iter == 0) if (found) cout << "X"; else cout << "O";
    return position;
}
int time_10_binarySearches(string *sa, int N, string *searchData, int max_SD) {
    clock_t seek_start = clock();
    cout << "Binary Seek results = ";
    for (int j = 0; j < 10000; j++)
    for (int i = 0; i < max_SD; i++) {
        binarySearch(sa, N, searchData[i], j);
    }
    clock_t totalTime = clock() - seek_start;
    cout << endl;       // for X's and O's
    return totalTime;
}
hashLink *hashSearch(hashSlot *hs, string *sa, int N, string searchString, int iter){
    int position = -1;
    bool found = false;
    
    int location = hashItem(searchString);
    hashLink *worker = hs[location].head;
    while (worker != 0 && worker->key != searchString) {
        worker = worker->next;
    }
    if (worker != 0) {
        found = true;
    }
    if (iter == 0) if (found) cout << "X"; else cout << "O";
    return worker;
}
int time_10_hashSearches(hashSlot *hs, string *sa, int N, 
                                string *searchData, int max_SD) {
    clock_t seek_start = clock();
    cout << "Hash   Seek results = ";
    for (int j = 0; j < 1000; j++)
    for (int i = 0; i < max_SD; i++) {
        hashSearch(hs, sa, N, searchData[i], j);
    }
    clock_t totalTime = clock() - seek_start;
    cout << endl;       // for X's and O's
    return totalTime;
}
/*
 * 
 */
int main(int argc, char** argv) {

//    memorySizeTests_StackAndHeap();
//    memorySizeTests_HeapOnly();
    class plotData {
    public:
        int N;
        int fill_time;
        int hash_fill_time;
        int sort_time;
        int linear_seek_time;
        int binary_seek_time;
        int hash_seek_time;
        int hash_delete_time;
        int delete_time;
    };
    plotData *pd = new plotData[10];
    int max_SD = 10;                    // max_SearchData, even number <= 10
                // ONLY TESTED FOR max_SD = 10
    string *searchData = new string[max_SD];             // on the stack


    //Initialize the random number generator
    srand(static_cast<unsigned int>(time(0)));

    int iter = 0;       // iteration counter
    int min_N = 100;    // s/b 300 is a power of 10 under 3e7
    int max_N = 3e7;    // don't go over 3e7 or heap error 3 bad_alloc
    // also watch max_signed_int is 2,147,483,647 (2e9)
    // at max_N = 3e7, array takes 4 bytes * 3e7 = 120 MB
    // at max_N = 3e7, strings take 20 chars * 3e7 = 600 MB
    // total = 720 MB, really takes about 1.5 GB from Operation System
    // as seen in System Monitor
    // each loop takes about 24 seconds to alloc,fill,delete (no sort or search)
    for (int N = min_N; N <= max_N; N *= 10) {
        pd[iter].N = N;
        clock_t tstart=clock();    // time(0) gives seconds, clock() gives ticks
        cout << "Allocating array..." << endl;
        string *sa = new string[N];     // allocate N string pointers on heap
                                        // keeps the array off the stack
                                        // easy to delete and resize
        cout << "New loop N = " << N << endl;
        cout << "Filling array..." << endl;
        clock_t fill_start = clock();
        fillArray(sa, N);
                // makes N random strings of 20 characters
                // uses lower case alpha only, but that can be changed
        pd[iter].fill_time = clock() - fill_start;
//**/        display("sa",sa,5);//        cout << "sa[" << 0 << "] = " << sa[0] << endl;

        hashSlot *hs = new hashSlot[26*26*26*26];     // 676 slots for hash table
                                                // default constructor inits 0
        for (int i = 0; i < 26*26*26*26; i++) {
            hs[i].head = NULL;  // i needed this ?? why doesn't new init ??
        }
        clock_t hash_fill_start = clock();
        cout << "Filling hash table..." << endl;
        fillHashTable(hs, sa, N);
        pd[iter].hash_fill_time = clock() - hash_fill_start;

        clock_t sort_start = clock();
        cout << "Sorting array..." << endl;
        quickSort(sa, 0, N-1);
                // quicksort the array in place
        pd[iter].sort_time = clock() - sort_start;
        display("sa",sa,5);//        cout << "sa[" << 0 << "] = " << sa[0] << endl;
        cout << "sa[" << N-1 << "] = " << sa[N-1] << endl;

        cout << "Setup searchData..." << endl;
        setupSearchData(sa, N, searchData, max_SD);
                // gets 5 equidistant strings from the list
                // including first and last
                // then makes 5 strings that are not in the list
        display("sd",searchData,10);
        cout << "Seeking array..." << endl;
        pd[iter].linear_seek_time = time_10_linearSearches(sa, N, searchData, max_SD);
        pd[iter].binary_seek_time = time_10_binarySearches(sa, N, searchData, max_SD);
        pd[iter].hash_seek_time   = time_10_hashSearches(hs, sa, N, searchData, max_SD);

        cout << "Deleting array..." << endl;
        clock_t delete_start = clock();
        delete[] sa;
        cout << "deleted." << endl;
        pd[iter].delete_time = clock() - delete_start;

        cout << "Deleting hash table..." << endl;
        clock_t hash_delete_start = clock();
        purgeHashTable(hs);     // delete hashLink's
        delete[] hs;    // hash table
        pd[iter].hash_delete_time = clock() - hash_delete_start;

        clock_t tend=clock();
        cout<<"Total Time taken = "<<tend-tstart<< endl <<endl;
        iter++;
    }
    cout << "Times shown are in milliseconds of clock ticks." << endl;
    cout << "N is array size.  1E6 runs in 17s.  1E7 runs in 3.5 min." << endl;
    cout << "Fill the array with 20 character string objects O(N)." << endl;
    cout << "H-Fill is hash fill from the array filled. O(N)" << endl;
    cout << "Sort the array with a recursive quicksort O(N log(N))." << endl;
    cout << "All searches are setup for 50% found and 50% not found." << endl;
    cout << "Linear(10)     means 10  linear searches  O(N)." << endl;
    cout << "Binary(1E5)    means 1E5 binary searches, O(log(N))." << endl;
    cout << "Hash-Seek(1E4) means 1E4 hash retrievals, O(1)+O(N)links." << endl;
    cout << "Delete the array O(N)." << endl;
    cout << "H-Del is hash delete table and chain links. O(N)" << endl;
    cout << endl;
    for (int iter = 0; iter < 10; iter++) {
        if (pd[iter].N > 0) {
            cout    << "Iter: " << iter
                    << "  N: "    << setw(8) << pd[iter].N 
                    << "  Fill:" << setw(5) << pd[iter].fill_time 
                    << "  H-Fill:" << setw(5) << pd[iter].hash_fill_time
                    << "  Sort:" << setw(6) << pd[iter].sort_time 
                    << "  Lin(10):" << setw(5) << pd[iter].linear_seek_time
                    << "  Bin(1E5):" << setw(4) << pd[iter].binary_seek_time
                    << "  H-S(1E4):" << setw(5) << pd[iter].hash_seek_time
                    << "  Del:" << setw(5) << pd[iter].delete_time
                    << "  H-Del:" << setw(5) << pd[iter].hash_delete_time
                    << endl;
        }
    }
//**/    memorySizeTests_StackAndHeap();
    return 0;
}

